package com.xiaomi.migc.sdk.mock;

import com.xiaomi.huyu.blink.client.BlinkClient;
import com.xiaomi.huyu.blink.client.ClientFactory;
import com.xiaomi.huyu.blink.client.Command;
import com.xiaomi.huyu.blink.client.Config;
import com.xiaomi.huyu.blink.client.model.BlinkResponse;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;

/**
 * @author mujiawang
 * @date 2018/8/29
 * @Version 1.0
 */
public class Test {

    public static void main(String[] args) {
        Config config = new Config(130438);
        BlinkClient blinkClient = ClientFactory.getInstance(config);
        Command command = new Command(1, 1);
        int seq = 10;
        String cmdName = "gamesdk.account.anonymouslogin.v2";
        AccountS2C.AnonymousLoginV2Req request = AccountS2C.AnonymousLoginV2Req.newBuilder()
                .setDevAppId(2882303761517543214L).setDeviceNo("_0103_MaeWbX8IOnMPX5v4taWe3").setCurrentChannel("test").build();
        byte[] sendPacket = MilinkPacketMock.mockUpstreamPacket(cmdName, request.toByteString(), seq);

        BlinkResponse response = blinkClient.invoke(command, sendPacket);

        try {
            AccountS2C.AnonymousLoginV2Rsp rsp = AccountS2C.AnonymousLoginV2Rsp.parseFrom(MilinkPacketMock.mockDownstreamPacket(response.getBody()));
            System.out.println(rsp.toString());
        } catch (Exception e) {

        }

    }
}
