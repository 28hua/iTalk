package com.xiaomi.migc.sdk.mock;

import com.xiaomi.huyu.blink.client.BlinkClient;
import com.xiaomi.huyu.blink.client.ClientFactory;
import com.xiaomi.huyu.blink.client.Command;
import com.xiaomi.huyu.blink.client.Config;
import com.xiaomi.huyu.blink.client.model.BlinkResponse;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class GetLoginAppAccountTest {

    private static AtomicInteger receiveCounter = new AtomicInteger(1);

    private static AtomicInteger errCounter = new AtomicInteger(1);

    public static void main(String[] args) {
        GetLoginAppAccountTest test = new GetLoginAppAccountTest();
        test.start(args);
    }

    public void start(String[] args) {
        int threadCount = 100;
        if (args.length == 1) {
            threadCount = Integer.valueOf(args[0]).intValue();
        }

        ThreadGroup group = new ThreadGroup("GetLoginAppAccount_Test");
        List<Thread> threads = new ArrayList<Thread>();
        for (int x = 0; x < threadCount; ++x) {
            Thread t = new WorkerThread(x, group);
            threads.add(t);
            t.start();
        }
    }
    public static class WorkerThread extends Thread {

        public WorkerThread(int in, ThreadGroup group) {
            super(group, "WorkerThread-" + in);
        }

        @Override
        public void run() {
            Config config = new Config(130438);
            BlinkClient blinkClient = ClientFactory.getInstance(config);
            Command command = new Command(1, 1);
            boolean f = true;
            while (f) {
                    int seq = 10;
                    String cmdName = "gamesdk.account.getloginappaccount";
                    AccountS2C.GetLoginAppAccountReq request = AccountS2C.GetLoginAppAccountReq.newBuilder().setFuid(73429)
                            .setDevAppId("2882303761517543214").setToke("_0103_MaeWbX8IOnMPX5v4taWe3/LjOng6fpKbqsbGzQE4llB1kJVtfOsAsDJiHX580ZmG").setCurrentChannel("test").build();
                    byte[] sendPacket = MilinkPacketMock.mockUpstreamPacket(cmdName, request.toByteString(), seq);

                    BlinkResponse response = blinkClient.invoke(command, sendPacket);
                    if (response.isSuccess()) {
                        receiveCounter.incrementAndGet();
                    } else {
                        errCounter.incrementAndGet();
                    }
                    Stat.getInstance().inc();
                }

        }

    }

    public static class Stat {
        private AtomicLong _count = new AtomicLong(0);

        private static Stat _instance = new Stat();

        public static Stat getInstance() {
            return _instance;
        }

        private Stat() {
            _printer = new RatePrinter(_count);
            _printer.setDaemon(true);
            _printer.start();
        }

        public void inc() {
            _count.incrementAndGet();
        }

        private RatePrinter _printer;

        private static class RatePrinter extends Thread {
            private long _last;
            private long _lastR;
            private long _loseR;

            private AtomicLong _c;

            public RatePrinter(AtomicLong c) {
                _c = c;
            }

            @Override
            public void run() {
                while (true) {
                    try {
                        long current = _c.get();
                        long currentR = receiveCounter.get();
                        long currentLose = errCounter.get();
                        System.out.println("Rate: " + (current - _last) + " req/s, receive rate:" + (currentR - _lastR)
                                + " req/s, lose rate:" + (currentLose - _loseR) + " req/s");
                        _last = current;
                        _lastR = currentR;
                        _loseR = currentLose;
                        Thread.sleep(1000L);
                    } catch (Throwable e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
