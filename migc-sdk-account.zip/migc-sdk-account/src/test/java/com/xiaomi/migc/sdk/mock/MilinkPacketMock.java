package com.xiaomi.migc.sdk.mock;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.xiaomi.huyu.blink.model.pb.MnsDownstream;
import com.xiaomi.huyu.blink.model.pb.MnsUpstream;

public class MilinkPacketMock {

    public static byte[] mockUpstreamPacket(String cmdName, ByteString busiData, int seq) {
        return MnsUpstream.UpstreamPacket.newBuilder().setServiceCmd(cmdName).setBusiBuff(busiData).setAppId(10).setQua("qua-10001")
                .setSeq(seq).build().toByteArray();
    }

    public static byte[] mockDownstreamPacket(byte[] data) throws InvalidProtocolBufferException {
        MnsDownstream.DownstreamPacket pocket = MnsDownstream.DownstreamPacket.parseFrom(data);
        return pocket.getBusiBuff().toByteArray();
    }
}
