package com.xiaomi.migc.sdk.common;

import com.xiaomi.miliao.zookeeper.EnvironmentType;
import com.xiaomi.miliao.zookeeper.ZKClient;
import com.xiaomi.miliao.zookeeper.ZKDataChangeListener;
import com.xiaomi.miliao.zookeeper.ZKFacade;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author mujiawang
 * @date 2018/8/2
 * @Version 1.0
 */
public enum  ForbiddenChannelUtils {

    INSTANCE;

    private ConcurrentHashMap<String, String> cacheOne = new ConcurrentHashMap<String, String>();

    private ConcurrentHashMap<String, String> cacheTwo = new ConcurrentHashMap<String, String>();


    private int cacheNo = 1;

    private final String configPath  = "/huyu/migc/bill/forbidden_channel";

    private final Logger logger = LoggerFactory.getLogger(ForbiddenChannelUtils.class);
    private ForbiddenChannelUtils() {
        initCache();
    }

    public boolean isForbidden(String channel) {
        String value = null;
        if (cacheNo == 1) {
            value = cacheOne.get(channel);

        } else {
            value = cacheTwo.get(channel);
        }

        if (StringUtils.isBlank(value)) {
            return false;
        } else {
            return true;
        }
    }



    private void initCache(){
        EnvironmentType environmentType = ZKFacade.getZKSettings().getEnvironmentType();
        ZKClient zkClient = ZKFacade.getClient(environmentType);
        String config = zkClient.getData(String.class, configPath);
        updateCache(config, cacheOne);
        zkClient.registerDataChanges(String.class, configPath, new ZKDataChangeListener<String>() {

            @SuppressWarnings({"rawtypes", "unchecked"})
            @Override
            public void onChanged(String s, String data) {
                long start = System.currentTimeMillis();
                logger.info("....... forbidden_channel zk config change start.......");
                ConcurrentHashMap<String, String> map = new ConcurrentHashMap();
                updateCache(data, map);
                synchronized (this) {
                    if (cacheNo==1) {
                        cacheTwo = map;
                        cacheNo = 2;
                    } else {
                        cacheOne = map;
                        cacheNo =1;
                    }
                }
                long end = System.currentTimeMillis();
                logger.info("....... forbidden_channel zk config change end, time spend is {}", end-start);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void updateCache(String config, ConcurrentHashMap<String, String> map) {
        try {
            Document document = DocumentHelper.parseText(config);
            Element root = document.getRootElement();
            java.util.List<Element> elements = root.elements();
            for (Element element : elements) {
                String cid = (String) element.element("cid").getData();
                map.put(cid, "1");
            }
        } catch (Exception e) {
            System.out.println(e);
            logger.error("", e);
        }
    }
}
