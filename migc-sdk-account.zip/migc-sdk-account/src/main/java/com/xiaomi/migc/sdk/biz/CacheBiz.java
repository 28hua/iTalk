package com.xiaomi.migc.sdk.biz;

import com.xiaomi.migc.sdk.common.OnOffUtils;
import com.xiaomi.migc.sdk.common.redis.RedisClient;
import com.xiaomi.migc.sdk.common.redis.RedisClusterClient;
import com.xiaomi.migc.sdk.model.AppAccountInfo;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author mujiawang
 * @date 2018/8/8
 * @Version 1.0
 */
@Service
public class CacheBiz {

    @Autowired
    private RedisClusterClient redisClusterClient;

    private static final int TIMEOUT = 300;

    private static final String ON_OFF_KEY = "imei_login_times_limit";

    private static final String imei_prefix = "account:imei:";

    private static final String app_prefix = "account:extid:";

    private static final String uid_prefix = "account:lastuid:";

    private static final String alipay_single_limit_prefix = "account:alipaysinglelimit:";

    private static final String alipay_single_day_limit = "account:alipaysingledaylimit";

    private static final Logger logger = LoggerFactory.getLogger(CacheBiz.class);

    public int getLoginTimesFor5Min(String imei) {

        if (StringUtils.isBlank(imei)) {
            return 1;
        }
        if (!OnOffUtils.INSTANCE.isOn(ON_OFF_KEY)) {
            return 1;
        }
        String key = imei_prefix + imei;
        String value = redisClusterClient.get(key);
        long time = System.currentTimeMillis();
        if (StringUtils.isBlank(value)) {
            redisClusterClient.setex(key, TIMEOUT, String.valueOf(time) + "|1");
            return 1;
        }
        int index = value.indexOf("|");
        String firstLoginTime = value.substring(0, index);
        int loginTimes = Integer.parseInt(value.substring(index + 1)) +1;
        String diffSeconds = String.valueOf((time - Long.parseLong(firstLoginTime))/1000);
        if (Integer.parseInt(diffSeconds)< TIMEOUT) {
            redisClusterClient.setex(key, TIMEOUT-Integer.parseInt(diffSeconds), firstLoginTime + "|" +String.valueOf(loginTimes));
        }
        return loginTimes;
    }

    public long getExtIdByDevAppId(long devAppId) {
        long extId = 0L;
        try {
            String key = app_prefix + devAppId;
            String extIdStr = redisClusterClient.get(key);
            if (StringUtils.isNotBlank(extIdStr)) {
                extId = Long.parseLong(extIdStr);
            }
        } catch (Exception e) {
            logger.error("", e);
        }
        return extId;
    }

    public void setExtIdByDevAppId(long devAppId, long extId) {
        try {
            String key = app_prefix + devAppId;
            redisClusterClient.set(key, String.valueOf(extId));
        } catch (Exception e) {
            logger.error("", e);
        }

    }

    public void setLastPlayedUid(long fuid, long devAppId, long uid, String imei) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(uid_prefix).append(fuid).append(":").append(devAppId);
            StringBuilder sb1 = new StringBuilder();
            if (StringUtils.isNotBlank(imei)) {
                sb1.append(uid).append(",").append(imei);
            } else {
                sb1.append(uid);
            }
            redisClusterClient.setex(sb.toString(),3600*24, sb1.toString());
        } catch (Exception e) {
            logger.error("", e);
        }
    }

    public void setLastPlayedUidForRecord(long fuid, long devAppId, long uid) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(uid_prefix).append(fuid).append(":").append(devAppId);
            String val = redisClusterClient.get(sb.toString());
            StringBuilder sb1 = new StringBuilder();
            if (StringUtils.isNotBlank(val)) {
                String[] arr = val.split(",");
                if (arr.length == 2) {
                    String imei = arr[1];
                    sb1.append(uid).append(",").append(imei);
                } else {
                    sb1.append(uid);
                }
            } else {
                sb1.append(uid);
            }
            redisClusterClient.setex(sb.toString(),3600*24, sb1.toString());
        } catch (Exception e) {
            logger.error("", e);
        }
    }

    public Long getLastPlayedUid(long fuid, long devAppId) {
        Long uid = null;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(uid_prefix).append(fuid).append(":").append(devAppId);
            String val = redisClusterClient.get(sb.toString());
            if (StringUtils.isNotBlank(val)) {
                String[] arr = val.split(",");
                String uidStr = arr[0];
                uid = Long.valueOf(uidStr);
            }
        } catch (Exception e) {
            logger.error("", e);
        }
        return uid;
    }

    public Long getLastPlayedUidByImei(long fuid, long devAppId, String imei) {
        Long uid = null;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(uid_prefix).append(fuid).append(":").append(devAppId);
            String val = redisClusterClient.get(sb.toString());
            if (StringUtils.isNotBlank(val)) {
                String[] arr = val.split(",");
                String uidStr = arr[0];
                if (arr.length == 2 && arr[1].equals(imei)) {
                    uid = Long.valueOf(uidStr);
                } else {
                    if (arr.length == 1) {
                        uid = Long.valueOf(uidStr);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("", e);
        }
        return uid;
    }

}
