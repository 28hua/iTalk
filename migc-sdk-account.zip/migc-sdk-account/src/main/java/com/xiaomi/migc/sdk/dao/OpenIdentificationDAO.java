package com.xiaomi.migc.sdk.dao;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;

@DAO(catalog = "migc_bill_accountuser")
public interface OpenIdentificationDAO {

    @ReturnGeneratedKeys
    @SQL("insert open_id_incr values ()")
    public long generateOpenId();
}
