package com.xiaomi.migc.sdk.services;

import com.xiaomi.huyu.blink.RpcInvocation;
import com.xiaomi.huyu.blink.ServiceResponse;
import com.xiaomi.huyu.blink.annotation.BlinkService;
import com.xiaomi.huyu.blink.annotation.Cmd;
import com.xiaomi.migc.sdk.biz.*;
import com.xiaomi.migc.sdk.common.RetCode;
import com.xiaomi.migc.sdk.common.SdkVersionUtils;
import com.xiaomi.migc.sdk.exception.BizException;
import com.xiaomi.migc.sdk.model.pb.AccountS2S;
import com.xiaomi.migc.sdk.model.pb.FuidS2S;
import com.xiaomi.migc.sdk.model.vo.AccountVo;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author mujiawang
 * @since 2017/10/31.
 */
@BlinkService
public class AccountS2SService {

    private static final Logger logger = LoggerFactory.getLogger(AccountS2SService.class);

    private static final Logger orderVerifyLogger = LoggerFactory.getLogger("orderVerifyLogger");

    @Autowired
    FuidBiz fuidBiz;

    @Autowired
    OpenSessionBiz openSessionBiz;

    @Autowired
    TokenBiz tokenBiz;

    @Autowired
    CacheBiz cacheBiz;

    @Autowired
    AccountBiz accountBiz;

    @Cmd(id = 1004, name = "gamesdk.account.verifyaccountinfo")
    public ServiceResponse verifyAccountInfo(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.verifyaccountinfo .......");
        AccountS2S.VerifyAccountInfoRsp.Builder builder = AccountS2S.VerifyAccountInfoRsp.newBuilder();
        ServiceResponse response = inv.getResponse();
        AccountS2S.VerifyAccountInfoReq request = null;
        String checkSessionResult = "";
        String checkSessionCacheResult = "";
        String xiaomiId = "0";
        String checkUidResult = "";
        String checkLastUidResult = "";
        String checkUidImeiResult = "";
        try {
            request = AccountS2S.VerifyAccountInfoReq.parseFrom(data);
            logger.info("[gamesdk.account.verifyaccountinfo req] " + request.toString());

            String fuIdStr = request.getFuId();
            String devAppIdStr = request.getDevAppId();
            String appAccountIdStr = request.getAppAccountId();
            AccountS2S.Platform platform = request.getPlatform();
            String sdkVersion = request.getSdkVersion();
            boolean result = false;

            if (AccountS2S.Platform.ANDROID.equals(platform)) {
                if (SdkVersionUtils.isNotCheckAccount(sdkVersion)) {
                    result = true;
                } else {
                    long fuid = Long.parseLong(fuIdStr);
                    long devAppId = Long.parseLong(devAppIdStr);
                    long appAccountId = Long.parseLong(appAccountIdStr);
                    String session = request.getSession();

                    FuidS2S.AccountInfo accountInfo = fuidBiz.getZhiboAccountInfoByUuid(fuid);
                    if (accountInfo != null && fuidBiz.isXiaomiUser(accountInfo)) {
                        xiaomiId = accountInfo.getOpenid();
                    }
                    boolean checkUid = checkUid(fuid, devAppId, appAccountId);
                    boolean checkLastUid = checkLastUid(fuid, devAppId, appAccountId);
                    boolean checkImei = checkImei(fuid, devAppId, appAccountId, request.getImei());
                    boolean checkSessionCache = checkSessionCache(fuid, devAppId, session, sdkVersion);
                    checkUidResult = checkUid ? "ok" : "no";
                    checkLastUidResult = checkLastUid? "Ok" : "No";
                    checkUidImeiResult = checkImei ? "OK" : "NO";
                    checkSessionCacheResult = checkSessionCache ? "TRUE" : "FALSE";
                    if (Long.parseLong(xiaomiId) > 0L) {
                        boolean checkSession = checkSession(Long.parseLong(xiaomiId), fuid, session, sdkVersion);
                        checkSessionResult = checkSession ? "true" : "false";
                    }
                    //打开uid校验，5.1.5 之后session校验, imei暂时只记录日志
                    if (checkUid && checkSessionCache) {
                        result = true;
                    }
                }
            } else if (AccountS2S.Platform.IOS.equals(platform)) {
                result = true;
            }
            if (result) {
                builder.setRetCode(RetCode.success.getCode());
                builder.setRetMsg(RetCode.success.getMessage());
            } else {
                builder.setRetCode(RetCode.VERIFY_ACCOUNT_INFO_ERROR.getCode());
                builder.setRetMsg(RetCode.VERIFY_ACCOUNT_INFO_ERROR.getMessage());
            }
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            builder.setRetMsg(RetCode.systemError.getMessage());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        orderVerifyLog(request, builder.getRetCode(), checkSessionResult, xiaomiId,
                checkSessionCacheResult, checkUidResult, checkUidImeiResult, checkLastUidResult);
        return response;
    }

    @Cmd(id = 1005, name = "gamesdk.account.getopenidbythirdopenid")
    public ServiceResponse getOpenIdByThirdOpenId(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.getopenidbythirdopenid .......");
        AccountS2S.GetOpenIdByThirdOpenIdRsp.Builder builder = AccountS2S.GetOpenIdByThirdOpenIdRsp.newBuilder();
        ServiceResponse response = inv.getResponse();
        try {
            AccountS2S.GetOpenIdByThirdOpenIdReq req = AccountS2S.GetOpenIdByThirdOpenIdReq.parseFrom(data);
            logger.info("[gamesdk.account.getopenidbythirdopenid req] " + req.toString());
            String thirdOpenId = req.getThirdOpenId();
            long devAppId = req.getDevAppId();
            int thirdCode = req.getThirdCode();
            if (StringUtils.isBlank(thirdOpenId) || devAppId <= 0L || thirdCode <= 0) {
                throw new BizException(RetCode.paramError);
            }
            AccountVo vo = accountBiz.getByThirdOpenId(thirdOpenId, devAppId, thirdCode);
            String session = openSessionBiz.genOpenSession(vo.getOpenId(), devAppId);
            builder.setRetCode(RetCode.success.getCode()).setOpenId(String.valueOf(vo.getOpenId()))
                            .setFuid(String.valueOf(vo.getFuid())).setSession(session);
        } catch (BizException be) {
            builder.setRetCode(be.getRetCode().getCode());
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        return response;
    }

    private void orderVerifyLog(AccountS2S.VerifyAccountInfoReq req,
                                int retCode,
                                String checkSessionResult,
                                String xiaomiId,
                                String checkSessionCacheResult,
                                String checkUidResult,
                                String checkUidImeiResult,
                                String checkLastUidResult) {
        if (req != null) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("fuid", req.getFuId());
            jsonObject.put("openId", req.getAppAccountId());
            jsonObject.put("devAppId", req.getDevAppId());
            jsonObject.put("session", req.getSession());
            jsonObject.put("sdkVersion", req.getSdkVersion());
            jsonObject.put("st", req.getSt());
            jsonObject.put("imei", req.getImei());
            jsonObject.put("ua", req.getUa());
            jsonObject.put("ip", req.getIp());
            jsonObject.put("uri", req.getUri());
            jsonObject.put("retCode", retCode);
            jsonObject.put("xiaomiId", xiaomiId);
            jsonObject.put("checkUidResult", checkUidResult);
            jsonObject.put("checkLastUidResult", checkLastUidResult);
            jsonObject.put("checkUidImeiResult", checkUidImeiResult);
            jsonObject.put("checkSessionResult", checkSessionResult);
            jsonObject.put("checkSessionCacheResult", checkSessionCacheResult);
            orderVerifyLogger.info(jsonObject.toString());
        }
    }

    private boolean checkUid(long fuid, long devAppId, long appAccountId) throws BizException{
        return accountBiz.verifyAccount(appAccountId, fuid, devAppId);
    }

    private boolean checkLastUid(long fuid, long devAppId, long appAccountId) {
        Long uid = cacheBiz.getLastPlayedUid(fuid, devAppId);
        if (uid != null && uid.longValue() == appAccountId) {
            return true;
        }
        return false;
    }

    private boolean checkImei(long fuid, long devAppId, long appAccountId, String imei) {
        Long uidImei = cacheBiz.getLastPlayedUidByImei(fuid, devAppId, imei);
        if (uidImei != null && uidImei.longValue() == appAccountId) {
            return true;
        }
        return false;
    }

    private boolean checkSessionCache(long fuid, long devAppId, String session, String sdkVersion) {
        return tokenBiz.isValidateWithAppId(fuid, devAppId, session, sdkVersion);
    }

    private boolean checkSession(long xiaomiId, long fuid, String session, String sdkVersion) {
        return tokenBiz.isValidate(xiaomiId, fuid, session, sdkVersion);
    }

}
