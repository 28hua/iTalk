package com.xiaomi.migc.sdk.biz;

import com.xiaomi.migc.sdk.common.Constants;
import com.xiaomi.migc.sdk.dao.AppAccountInfoDAO;
import com.xiaomi.migc.sdk.dao.OpenIdentificationDAO;
import com.xiaomi.migc.sdk.model.AppAccountInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * 
 * @author jhw
 *
 */
@Service
public class AppAccountInfoBiz {

    @Autowired
    private AppAccountInfoDAO appAccountInfoDAO;

    @Autowired
    private OpenIdentificationDAO openIdentificationDAO;

    @Autowired
    private AppBiz appBiz;

    private static Lock lock = new ReentrantLock();

    /**
     * 
     * 根据xiaomiId查询游戏账号列表
     * 
     * @param xiaomiId
     * @return
     */
    public List<AppAccountInfo> findAppAccountInfosByXiaomiId(long xiaomiId, long appId) {
        appId = getAppMasterExtId(appId);

        List<AppAccountInfo> appAccountInfos = appAccountInfoDAO.findAppAccountInfosByAppAndXiaomiId(xiaomiId, appId);
        return appAccountInfos;
    }

    public AppAccountInfo getLastPlayedAppAccount(long xiaomiId, long devAppId,long fuid) {

        long extId = getAppMasterExtId(devAppId);
        AppAccountInfo ainfo = null;
        lock.lock();
        try {

            List<AppAccountInfo> infos = appAccountInfoDAO.listAppAccountByAppIdAndXiaomiId(extId, xiaomiId);

            if (infos == null || infos.size() == 0) {
            	long openId = openIdentificationDAO.generateOpenId();
                ainfo = new AppAccountInfo();
                ainfo.setAccountStatus(Constants.ACCOUNT_STATUS_ON);
                ainfo.setAccountType(Constants.ACCOUNT_TYPE_DEFAULT);
                ainfo.setAppAccountAlias(fuid);
                ainfo.setAppAccountId(openId);
                ainfo.setAppAccountName(Constants.DEFAULT_ACCOUNT_NAME);
                ainfo.setAppId(extId);
                Date d = new Date();
                ainfo.setCreateTime(d);
                ainfo.setLastPlayedTime(d);
                ainfo.setUpdateTime(d);
                ainfo.setXiaomiId(xiaomiId);
                appAccountInfoDAO.saveAppAccountInfo(xiaomiId, ainfo);
                //first
                ainfo.setFirstLogin(true);
            } else {
                long lastPlayedTime = 0L;
                int index = 0;
                for (int i=0; i<infos.size(); i++) {
                    AppAccountInfo info = infos.get(i);
                    if (info.getLastPlayedTime() != null && info.getLastPlayedTime().getTime() >= lastPlayedTime) {
                        lastPlayedTime = info.getLastPlayedTime().getTime();
                        index = i;
                    }
                }
                ainfo = infos.get(index);
            }
            
        }finally {
        	lock.unlock();
        }
        return ainfo;
    }

    public AppAccountInfo getAppAccountInfoByAppAndAlias(long openId,long devAppId, long xiaomiId) {

        long extId = getAppMasterExtId(devAppId);
        return appAccountInfoDAO.getAppAccountInfoByAppAndAlias(xiaomiId,openId, extId);
    }
    
    public long getAppMasterExtId(long devAppId) {
        return appBiz.getAppMasterExtId(devAppId);
    }


}
