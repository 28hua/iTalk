package com.xiaomi.migc.sdk.common;

import com.xiaomi.migc.sdk.model.pb.AccountS2C;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mujiawang
 * @date 2018/8/29
 * @Version 1.0
 */
public class AnonymousLoginUtils {

    private static final Logger anonymousLoginLogger = LoggerFactory.getLogger("anonymousLoginLogger");

    public static void log(AccountS2C.AnonymousLoginV2Req req, long fuid, int retCode) {
        try {
            JSONObject dataJson = new JSONObject();
            dataJson.put("devAppId", req.getDevAppId());
            dataJson.put("deviceNo", req.getDeviceNo());
            dataJson.put("fuid", fuid);
            dataJson.put("imei", req.getImei());
            dataJson.put("imsi", req.getImsi());
            dataJson.put("sdkVersion", req.getSdkVersion());
            dataJson.put("channel", req.getChannel());
            dataJson.put("ua", req.getUa());
            dataJson.put("currentChannel", req.getCurrentChannel());
            dataJson.put("imeiMd5", req.getImeiMd5());
            dataJson.put("firstChannel", req.getFirstChannel());
            dataJson.put("retCode", retCode);
            String ts = String.valueOf(System.currentTimeMillis());
            dataJson.put("ts", ts);

            anonymousLoginLogger.info(dataJson.toString());
        } catch (Exception e) {
            anonymousLoginLogger.error("", e);
        }

    }
}
