package com.xiaomi.migc.sdk.services;

import com.xiaomi.huyu.blink.RpcInvocation;
import com.xiaomi.huyu.blink.ServiceResponse;
import com.xiaomi.huyu.blink.annotation.BlinkService;
import com.xiaomi.huyu.blink.annotation.Cmd;
import com.xiaomi.migc.sdk.biz.TokenBiz;
import com.xiaomi.migc.sdk.biz.FuidBiz;
import com.xiaomi.migc.sdk.common.RetCode;
import com.xiaomi.migc.sdk.common.json.JsonUtil;
import com.xiaomi.migc.sdk.model.pb.AccountS2C.GetServiceTokenReq;
import com.xiaomi.migc.sdk.model.pb.AccountS2C.GetServiceTokenRsp;
import com.xiaomi.migc.sdk.model.pb.FuidS2S;
import com.xiaomi.migc.sdk.model.vo.TokenVo;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

@BlinkService
public class TokenService {

	private static final Logger logger = LoggerFactory.getLogger(TokenService.class);

	private static final Logger tokenlogger = LoggerFactory.getLogger("serviceTokenLogger");
	
	@Autowired
	private TokenBiz tokenBiz;
	@Autowired
	private FuidBiz fuidBiz;
	
	@Cmd(id = 1, name = "gamesdk.account.getservicetoken")
	public ServiceResponse getServiceToken(RpcInvocation inv, byte[] data) {
		logger.info("enter gamesdk.account.getst .......");
        GetServiceTokenRsp.Builder  builder = GetServiceTokenRsp.newBuilder();
        ServiceResponse response = inv.getResponse();
		GetServiceTokenReq request = null;
		TokenVo vo = null;
        
        try {
        	request = GetServiceTokenReq.parseFrom(data);
        	logger.info("[gamesdk.account.getst req] " + request.toString());
            
        	Long fuid = request.getFuid();
        	String strDevAppId = request.getDevAppId();
			Long devAppId = Long.valueOf(strDevAppId);
			String token = request.getToke();
//			if (zhiboAccountBiz.isValidateToken(token, fuid)) {
				long xiaomiId = getXiaomiIdByFuid(fuid);

				vo = tokenBiz.createServiceToken(fuid, xiaomiId, devAppId, request.getSdkVersion());

				String json = JsonUtil.json(vo);

				logger.info("The return json is : " + json);
				builder.setRetCode(RetCode.success.getCode());
				builder.setServiceToken(json);
//			} else {
//				builder.setRetCode(RetCode.verifyServiceTokenError.getCode());
//			}
			
        } catch (Exception e) {
        	builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
		}
        response.setBody(builder.build().toByteArray());
        log(request, builder.getRetCode(), vo);
        return response;
	}
	
	private long getXiaomiIdByFuid(long fuid) {
		FuidS2S.AccountInfo info = fuidBiz.getZhiboAccountInfoByUuid(fuid);
		if(info != null && fuidBiz.isXiaomiUser(info)) {
			String mid =  info.getOpenid();
			
			return Long.valueOf(mid).longValue();
		}else{
			logger.info("The mid is null.");
		}

		return 0l;
	}

	private void log(GetServiceTokenReq req, int retCode, TokenVo vo) {
		if (req != null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("fuid", req.getFuid());
			jsonObject.put("devAppId", req.getDevAppId());
			jsonObject.put("st", req.getToke());
			jsonObject.put("imei", req.getImei());
			jsonObject.put("imsi", req.getImsi());
			jsonObject.put("sdkVersion", req.getSdkVersion());
			jsonObject.put("channel", req.getChannel());
			jsonObject.put("ua", req.getUa());
			jsonObject.put("currentChannel", req.getCurrentChannel());
			jsonObject.put("imeiMd5", req.getImeiMd5());
			jsonObject.put("firstChannel", req.getFirstChannel());
			jsonObject.put("retCode", retCode);
			if (vo != null) {
				jsonObject.put("session", vo.getSession());
				jsonObject.put("key", vo.getKey());
				jsonObject.put("t", vo.getT());
				jsonObject.put("nickName", vo.getNickName());
				jsonObject.put("akey", vo.getAkey());
				jsonObject.put("lastCheckAuthTime", vo.getLastCheckAuthTime());
				jsonObject.put("mid", vo.getMid());
			}
			tokenlogger.info(jsonObject.toString());
		}
	}
}
