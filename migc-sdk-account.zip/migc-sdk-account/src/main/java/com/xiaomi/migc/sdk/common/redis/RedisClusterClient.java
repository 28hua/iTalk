package com.xiaomi.migc.sdk.common.redis;

import redis.clients.jedis.JedisCluster;

public class RedisClusterClient {

	private JedisCluster jedisCluster;
	
	public RedisClusterClient(JedisCluster jedisCluster) {
		this.jedisCluster = jedisCluster;
	}
	
	public void set(String key, String value) {
		jedisCluster.set(key, value);
		
		
	}
	
	public String get(String key) {
		return jedisCluster.get(key);
	}
	
	public void setex(String key, int seconds, String value) {
		jedisCluster.setex(key, seconds, value);
	}
	
}
