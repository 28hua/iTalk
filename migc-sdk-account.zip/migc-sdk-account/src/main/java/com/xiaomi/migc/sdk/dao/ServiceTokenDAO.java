package com.xiaomi.migc.sdk.dao;

import com.xiaomi.bmw.jade.route.annotation.UseSlave;
import com.xiaomi.migc.sdk.model.ServiceToken;
import com.xiaomi.migc.sdk.model.vo.TokenVo;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.SQLParam;
import net.paoding.rose.jade.annotation.ShardBy;
import net.paoding.rose.jade.annotation.UseMaster;

@DAO(catalog="migc_bill_accountuser")
public interface ServiceTokenDAO {

	@UseMaster
	@SQL("insert into service_token_info(user_id,xiaomi_id,token_session,token_key,akey,create_time,nick_name,last_check_auth_time) "
			+ "values (:t.uid,:t.mid,:t.session,:t.key,:t.akey,:t.t,:t.nickName,:t.lastCheckAuthTime)")
	public void saveServiceToken(@ShardBy long xiaomiId, @SQLParam("t")TokenVo serviceToken);
	
	@UseSlave
	@SQL("select user_id,xiaomi_id,token_session,token_key,akey,create_time,nick_name,last_check_auth_time from service_token_info where user_id = :id and token_session = :s")
	public ServiceToken getServiceToken(@ShardBy long xiaomiId,@SQLParam("id")long userId,@SQLParam("s")String session);
	
}