package com.xiaomi.migc.sdk.services;

import com.xiaomi.huyu.blink.RpcInvocation;
import com.xiaomi.huyu.blink.ServiceResponse;
import com.xiaomi.huyu.blink.annotation.BlinkService;
import com.xiaomi.huyu.blink.annotation.Cmd;
import com.xiaomi.migc.sdk.biz.*;
import com.xiaomi.migc.sdk.common.*;
import com.xiaomi.migc.sdk.exception.BizException;
import com.xiaomi.migc.sdk.model.GameAccountAnonymous;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;
import com.xiaomi.migc.sdk.model.pb.AccountS2C.*;
import com.xiaomi.migc.sdk.model.pb.KnightS2S;
import com.xiaomi.migc.sdk.model.vo.AccountVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@BlinkService
public class AccountService {

    private static final Logger logger = LoggerFactory.getLogger(AccountService.class);

    @Autowired
    private OpenSessionBiz openSessionBiz;
    @Autowired
    private FuidBiz fuidBiz;
    @Autowired
    private KnightServiceBiz knightServiceBiz;
    @Autowired
    private CacheBiz cacheBiz;
    @Autowired
    private EventDistributeBiz eventDistributeBiz;
    @Autowired
    private AnonymousAccountBiz anonymousAccountBiz;
    @Autowired
    private UserChannelBiz userChannelBiz;
    @Autowired
    private AccountBiz accountBiz;

    @Cmd(id = 1, name = "gamesdk.account.getloginappaccount")
    public ServiceResponse getLoginAppAccount(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.getloginappaccount .......");
        GetLoginAppAccountRsp.Builder builder = GetLoginAppAccountRsp.newBuilder();
        ServiceResponse response = inv.getResponse();
        GetLoginAppAccountReq request = null;
        long openId = 0L;
        try {
            request = GetLoginAppAccountReq.parseFrom(data);
            logger.info("[gamesdk.account.getloginappaccount req] " + request.toString());
            long fuid = request.getFuid();
            String strDevAppId = request.getDevAppId();
            long devAppId = Long.parseLong(strDevAppId);
            String token = request.getToke();
            String imei = request.getImei();
            if (isForbiddenChannel(request.getCurrentChannel())) {
                throw new BizException(RetCode.forbiddenChannel);
            }
            if (cacheBiz.getLoginTimesFor5Min(imei) > 10) {
                logger.error("imei login times > 10, imei:{}", imei);
                throw new BizException(RetCode.loginTimes5MinError);
            }
            AccountVo vo = accountBiz.getLastLoginAccount(fuid, devAppId, imei);
            openId = vo.getOpenId();
            String session = openSessionBiz.genOpenSession(openId, devAppId);
            builder.setSession(session).setRetCode(RetCode.success.getCode()).setAppAccountId(openId).setNickName(vo.getNickName());
            eventDistributeBiz.loginEvent(request, builder.getRetCode(), vo.getXiaomiId(), vo.isFirst(), openId, session);
        } catch (BizException be) {
            builder.setRetCode(be.getRetCode().getCode());
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        LoginLcsUtils.log(request, builder.getRetCode(), openId);
        response.setBody(builder.build().toByteArray());
        return response;
    }


    @Cmd(id = 1, name = "gamesdk.account.getappaccounts")
    public ServiceResponse getAppAccounts(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.getappaccounts .......");
        GetAppAccountsRsp.Builder builder = GetAppAccountsRsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            GetAppAccountsReq request = GetAppAccountsReq.parseFrom(data);
            logger.info("[gamesdk.account.getappaccounts req] " + request.toString());

            long fuid = request.getFuid();
            String strDevAppId = request.getDevAppId();
            long devAppId = Long.parseLong(strDevAppId);
            String token = request.getToke();
            builder.setDefaultAccountId(0L);
            List<AccountVo> voList = accountBiz.listAccounts(fuid, devAppId);

            for (AccountVo user : voList) {
                if (user.getAccountType() == Constants.ACCOUNT_TYPE_DEFAULT) {
                    builder.setDefaultAccountId(user.getOpenId());
                }
                String session = openSessionBiz.genOpenSession(user.getOpenId(), devAppId);
                AccountS2C.AppAccountVo vo = AccountS2C.AppAccountVo.newBuilder().setAppAccountId(user.getOpenId())
                        .setAppAccountName(user.getAccountName()).setLastLoginTime(user.getLastPlayedTime())
                        .setSession(session).build();
                builder.addAccounts(vo);
            }
            builder.setRetCode(RetCode.success.getCode());

        } catch (BizException be) {
            builder.setRetCode(be.getRetCode().getCode());
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        return response;
    }

    @Cmd(id = 1, name = "gamesdk.account.recordloginaccount")
    public ServiceResponse recordLoginAccount(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.recordloginaccount .......");
        RecordLoginAppAccountRsp.Builder builder = RecordLoginAppAccountRsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            RecordLoginAppAccountReq request = RecordLoginAppAccountReq.parseFrom(data);
            logger.info("[gamesdk.account.recordloginaccount req] " + request.toString());

            long fuid = request.getFuid();
            String strDevAppId = request.getDevAppId();
            long devAppId = Long.parseLong(strDevAppId);
            long openId = request.getAppAccountId();
            String token = request.getToke();
            accountBiz.saveLastPlayedAccount(fuid, devAppId, openId);
            builder.setRetCode(RetCode.success.getCode());
        } catch (BizException be) {
            builder.setRetCode(be.getRetCode().getCode());
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        return response;
    }


    @Cmd(id = 1, name = "gamesdk.account.getloginappaccount.v2")
    public ServiceResponse getLoginAppAccountV2(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.getloginappaccount.v2 .......");
        GetLoginAppAccountRsp.Builder builder = GetLoginAppAccountRsp.newBuilder();
        ServiceResponse response = inv.getResponse();
        GetLoginAppAccountReq request = null;
        long openId = 0L;
        try {
            request = GetLoginAppAccountReq.parseFrom(data);
            logger.info("[gamesdk.account.getloginappaccount.v2 req] " + request.toString());

            long fuid = request.getFuid();
            String strDevAppId = request.getDevAppId();
            long devAppId = Long.parseLong(strDevAppId);
            String token = request.getToke();
            String imei = request.getImei();
            if (isForbiddenChannel(request.getCurrentChannel())) {
                throw new BizException(RetCode.forbiddenChannel);
            }
            if (cacheBiz.getLoginTimesFor5Min(imei) > 10) {
                logger.error("imei login times > 10, imei:{}", imei);
                throw new BizException(RetCode.loginTimes5MinError);
            }
            if (!fuidBiz.isValidateToken(token, fuid)) {
                throw new BizException(RetCode.verifyServiceTokenError);
            }
            AccountVo vo = accountBiz.getLastLoginAccount(fuid, devAppId, imei);
            openId = vo.getOpenId();
            String session = openSessionBiz.genOpenSession(vo.getOpenId(), devAppId);
            builder.setSession(session).setRetCode(RetCode.success.getCode()).setAppAccountId(openId).setNickName(vo.getNickName());

            eventDistributeBiz.loginEvent(request, builder.getRetCode(), vo.getXiaomiId(), vo.isFirst(), openId, session);
        } catch (BizException be) {
            builder.setRetCode(be.getRetCode().getCode());
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        LoginLcsUtils.log(request, builder.getRetCode(), openId);
        response.setBody(builder.build().toByteArray());
        return response;
    }

    @Cmd(id = 1, name = "gamesdk.account.anonymouslogin")
    public ServiceResponse anonymousLogin(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.anonymouslogin .......");
        AccountS2C.AnonymousLoginRsp.Builder builder = AccountS2C.AnonymousLoginRsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            AccountS2C.AnonymousLoginReq req = AccountS2C.AnonymousLoginReq.parseFrom(data);
            long devAppId = req.getDevAppId();
            String deviceNo = req.getDeviceNo();
            if (StringUtils.isBlank(deviceNo)) {
                throw new Exception("param deviceNo is null");
            }
            String channel = req.getChannel();
            GameAccountAnonymous account = anonymousAccountBiz.getAnonymousAccount(devAppId, deviceNo, channel);
            long openId = account.getOpenId();
            String session = openSessionBiz.genOpenSession(openId, devAppId);

            builder.setRetCode(RetCode.success.getCode());
            builder.setOpenId(openId);
            builder.setSession(session);
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }

        response.setBody(builder.build().toByteArray());
        return response;
    }

    @Cmd(id = 1, name = "gamesdk.account.anonymouslogin.v2")
    public ServiceResponse anonymousLoginV2(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.anonymouslogin.v2 .......");
        AccountS2C.AnonymousLoginV2Rsp.Builder builder = AccountS2C.AnonymousLoginV2Rsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            AccountS2C.AnonymousLoginV2Req req = AccountS2C.AnonymousLoginV2Req.parseFrom(data);
            long devAppId = req.getDevAppId();
            String deviceNo = req.getDeviceNo();
            if (StringUtils.isBlank(deviceNo)) {
                throw new Exception("param deviceNo is null");
            }
            String channel = req.getChannel();
            GameAccountAnonymous account = anonymousAccountBiz.getAnonymousAccountV2(devAppId, deviceNo.trim(), channel);
            if (account.getFuid() <= 0L) {
                throw new Exception("fuid get error");
            }
            long openId = account.getOpenId();
            String session = openSessionBiz.genOpenSession(openId, devAppId);

            builder.setRetCode(RetCode.success.getCode()).setOpenId(openId).setSession(session).setFuid(account.getFuid());
            AnonymousLoginUtils.log(req, account.getFuid(), RetCode.success.getCode());
            userChannelBiz.setUserChannelForAnonymous(req, account.getFuid(), builder.getRetCode());
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }

        response.setBody(builder.build().toByteArray());
        return response;
    }

    @Cmd(id = 1, name = "gamesdk.account.setuserinfo")
    public ServiceResponse setUserInfo(RpcInvocation inv, byte[] data) {
        logger.info("enter gamesdk.account.setuserinfo.......");
        SetUserInfoToGameCenterRsp.Builder builder = SetUserInfoToGameCenterRsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            SetUserInfoToGameCenterReq request = SetUserInfoToGameCenterReq.parseFrom(data);
            logger.info("[gamesdk.account.setuserinfo req :" + request.toString());

            long fuid = request.getFuid();
            String token = request.getToke();

            if (fuidBiz.isValidateToken(token, fuid)) {
                KnightS2S.SetUserInfoIfNotExistRsp ksRsp =
                        knightServiceBiz.setKnightUserInfo(request);

                if (ksRsp != null) {
                    if (ksRsp.getRetCode() == 0) {
                        builder.setRetCode(RetCode.success.getCode());
                    } else {
                        builder.setRetCode(ksRsp.getRetCode());
                    }
                    builder.setErrMsg(ksRsp.getErrMsg());
                } else {
                    builder.setRetCode(RetCode.setUserInfoError.getCode());
                }
            } else {
                builder.setRetCode(RetCode.verifyServiceTokenError.getCode());
            }
        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        return response;
    }

    private boolean isForbiddenChannel(String currentChannel) {
        if (StringUtils.isNotBlank(currentChannel)) {
            return ForbiddenChannelUtils.INSTANCE.isForbidden(currentChannel);
        } else {
            return false;
        }

    }

}
