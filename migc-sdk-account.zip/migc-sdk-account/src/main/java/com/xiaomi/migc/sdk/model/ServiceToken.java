package com.xiaomi.migc.sdk.model;

public class ServiceToken {

	private long userId;
	private long xiaomiId;
	private String tokenSession;
	private String tokenKey;
	private String akey;
	private String nickName;
	private long createTime;
	private long lastCheckAuthTime;
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getXiaomiId() {
		return xiaomiId;
	}
	public void setXiaomiId(long xiaomiId) {
		this.xiaomiId = xiaomiId;
	}
	public String getTokenSession() {
		return tokenSession;
	}
	public void setTokenSession(String tokenSession) {
		this.tokenSession = tokenSession;
	}
	public String getTokenKey() {
		return tokenKey;
	}
	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}
	public String getAkey() {
		return akey;
	}
	public void setAkey(String akey) {
		this.akey = akey;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}
	public long getLastCheckAuthTime() {
		return lastCheckAuthTime;
	}
	public void setLastCheckAuthTime(long lastCheckAuthTime) {
		this.lastCheckAuthTime = lastCheckAuthTime;
	}
}
