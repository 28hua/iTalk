package com.xiaomi.migc.sdk.model;

import java.util.Date;

public class GameAccountAnonymous {

    private long id;

    private long devAppId;

    private long openId;

    private String deviceNo;

    private Date createTime;

    private long fuid = 0L;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDevAppId() {
        return devAppId;
    }

    public void setDevAppId(long devAppId) {
        this.devAppId = devAppId;
    }

    public long getOpenId() {
        return openId;
    }

    public void setOpenId(long openId) {
        this.openId = openId;
    }

    public String getDeviceNo() {
        return deviceNo;
    }

    public void setDeviceNo(String deviceNo) {
        this.deviceNo = deviceNo;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public long getFuid() {
        return fuid;
    }

    public void setFuid(long fuid) {
        this.fuid = fuid;
    }
}
