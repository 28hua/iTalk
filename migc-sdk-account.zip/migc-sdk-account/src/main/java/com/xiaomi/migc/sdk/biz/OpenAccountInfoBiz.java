package com.xiaomi.migc.sdk.biz;

import com.xiaomi.migc.sdk.common.DateUtils;
import com.xiaomi.migc.sdk.dao.AppAccountInfoDAO;
import com.xiaomi.migc.sdk.dao.OpenAccountInfoDAO;
import com.xiaomi.migc.sdk.dao.OpenIdentificationDAO;
import com.xiaomi.migc.sdk.model.AppAccountInfo;
import com.xiaomi.migc.sdk.model.OpenAccountInfo;
import com.xiaomi.migc.sdk.model.pb.FuidS2S;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
public class OpenAccountInfoBiz {

	@Autowired
	private OpenAccountInfoDAO openAccountInfoDAO;

	@Autowired
	private OpenIdentificationDAO openIdentificationDAO;

	@Autowired
	private AppAccountInfoDAO appAccountInfoDAO;

	@Autowired
	private FuidBiz fuidBiz;

	@Autowired
	private AppAccountInfoBiz appAccountInfoBiz;

	private static Lock lock = new ReentrantLock();

	public OpenAccountInfo getAccountInfo(Long fuid, Long devAppId) {
		OpenAccountInfo info = null;
		lock.lock();
		try {
			info = openAccountInfoDAO.getOpenAccountInfo(fuid, devAppId);
			if (info == null) {
				info = new OpenAccountInfo();
				info.setAppAccountId(genAppAccountId());
				info.setDevAppId(devAppId);
				info.setFuid(fuid);
				info.setAccountStatus(default_account_status);
				info.setAccountType(default_account_type);
				Date d = new Date();
				info.setCreateTime(d);
				info.setLastPlayedTime(d);
				info.setUpdateTime(d);
				openAccountInfoDAO.create(info);
				// first login
				info.setFirstLogin(true);
			}
		} finally {
			lock.unlock();
		}
		return info;
	}

	public OpenAccountInfo getByFuIdAndDevAppIdAndAppAccountId(long appAccountId, long devAppId, long fuid) {
		OpenAccountInfo info = openAccountInfoDAO.getByFuIdAndDevAppIdAndAppAccountId(fuid, devAppId, appAccountId);
		return info;
	}

	public boolean verifyaccountinfo(long appAccountId, long devAppId, long fuId) {

		OpenAccountInfo info = openAccountInfoDAO.getByFuIdAndDevAppIdAndAppAccountId(fuId, devAppId, appAccountId);
		if (info == null) {
			FuidS2S.AccountInfo accountInfo = fuidBiz.getZhiboAccountInfoByUuid(fuId);
			if (accountInfo != null && fuidBiz.isXiaomiUser(accountInfo)) {
				String xiaomiId = accountInfo.getOpenid();

				//由于原来的账号支持pad和手机的应用绑定，所以需要判断一下游戏关联的主游戏ID是什么

				long extId = appAccountInfoBiz.getAppMasterExtId(devAppId);
				AppAccountInfo appAccountInfo = appAccountInfoDAO.getByXiaomiIdAndAppIdAndAlias(Long.parseLong(xiaomiId), extId, appAccountId);
				if (appAccountInfo != null) {
					return true;
				}
			}
		} else {
			return true;
		}
		return false;
	}

	private Long genAppAccountId() {
		Date date = new Date();
		StringBuilder sb = new StringBuilder();
		sb.append(DateUtils.format(date, "yyyyMMdd"));
		// 读数据库表，获取openid后六位
		long idInc = openIdentificationDAO.generateOpenId();

		long id = idInc % ID_CYCLE;

		DecimalFormat df = new DecimalFormat("00000000");
		sb.append(df.format(id));
		return Long.valueOf(sb.toString());
	}

	private static final int default_account_status = 1;
	private static final int default_account_type = 1;

	private static final int ID_CYCLE = 10000000;
}
