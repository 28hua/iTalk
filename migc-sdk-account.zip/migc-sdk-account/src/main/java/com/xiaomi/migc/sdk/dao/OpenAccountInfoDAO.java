package com.xiaomi.migc.sdk.dao;

import java.util.Date;

import com.xiaomi.migc.sdk.model.OpenAccountInfo;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.SQLParam;
import net.paoding.rose.jade.annotation.UseMaster;

@DAO(catalog = "migc_bill_manageruser")
public interface OpenAccountInfoDAO {

    public static final String table_name = "open_account_info";
    public static final String insert_column = "fuid,app_account_id,dev_app_id,ext_id,app_account_name,account_type,account_status,create_time,last_played_time,update_time";
    public static final String all_columns = "id," + insert_column;

    @UseMaster
    @ReturnGeneratedKeys
    @SQL("insert into "
            + table_name
            + " ("
            + insert_column
            + ") values (:u.fuid,:u.appAccountId,:u.devAppId,:u.extId,:u.appAccountName,:u.accountType,:u.accountStatus,:u.createTime,:u.lastPlayedTime,:u.updateTime)")
    public Long create(@SQLParam("u") OpenAccountInfo info);

    @UseMaster
    @SQL("select " + all_columns + " from " + table_name + " where fuid =:fuid and dev_app_id = :devAppId limit 1")
    public OpenAccountInfo getOpenAccountInfo(@SQLParam("fuid") Long fuid, @SQLParam("devAppId") Long devAppId);

    @UseMaster
    @SQL("select " + all_columns + " from " + table_name + " where fuid =:fuid and dev_app_id = :devAppId and app_account_id =:appAccountId ")
    OpenAccountInfo getByFuIdAndDevAppIdAndAppAccountId(@SQLParam("fuid") Long fuid,
                                                               @SQLParam("devAppId") Long devAppId,
                                                               @SQLParam("appAccountId") Long appAccountId);

}
