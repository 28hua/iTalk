package com.xiaomi.migc.sdk.common;

public class Constants {

	public static final String DEFAULT_ACCOUNT_NAME = "默认账号";
    public static final String DEFAULT_APP_ACCOUNT_NAME = "角色";
    public static final int ACCOUNT_STATUS_OFF = 0;
    public static final int ACCOUNT_STATUS_ON = 1;
    public static final int ACCOUNT_TYPE_DEFAULT = 1;
    public static final int ACCOUNT_TYPE_ROLE = 2;
}
