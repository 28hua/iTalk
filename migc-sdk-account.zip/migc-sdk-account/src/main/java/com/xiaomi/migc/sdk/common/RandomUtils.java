package com.xiaomi.migc.sdk.common;

import java.util.Random;

/**
 * 随机数生成工具类
 * 
 * @author hw
 *
 */
public class RandomUtils {

    private static String ALL_CHAR = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static String ALL_NUM = "123456789";

    /**
     * 生成指定位数随即字符串
     * 
     * @param length
     * @return
     */
    public static String getRandomStr(int length) {
        StringBuffer sb = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(ALL_CHAR.charAt(random.nextInt(ALL_CHAR.length())));
        }
        return sb.toString();
    }

    public static String getRandomNum(int length) {
        StringBuffer sb = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(ALL_NUM.charAt(random.nextInt(ALL_NUM.length())));
        }
        return sb.toString();
    }
}
