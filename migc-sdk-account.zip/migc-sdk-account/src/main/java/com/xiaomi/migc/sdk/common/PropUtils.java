package com.xiaomi.migc.sdk.common;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.huyu.blink.BlinkConstants;
import com.xiaomi.huyu.blink.utils.ConfigUtils;

public class PropUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(PropUtils.class);
	private static Properties properties = ConfigUtils.loadProperties(BlinkConstants.Properties.DEFAULT_APPLICATION_PROPERTIES); 
	
	public static int getUserProfileModelId() {
		Integer id = 0;
        if (properties != null) {
            id =  Integer.valueOf(properties.getProperty("zhibo.modid.userprofile", "0"));
            logger.info("the zhibo user profile model id :" + id.intValue());
        }
        return id.intValue();
	}
	
	public static int getZhiboAccountModelId() {
		Integer id = 0;
        if (properties != null) {
            id = Integer.valueOf(properties.getProperty("zhibo.modid.account", "0"));
            logger.info("the zhibo account model id :" + id.intValue());
        }
        return id.intValue();
	}
	
    public static int getSetUserChannelModelId() {
		Integer id = 0;
        if (properties != null) {
            id = Integer.valueOf(properties.getProperty("user.channel.set", "0"));
            logger.info("the set user channel model id :" + id.intValue());
        }
        return id.intValue();
	}
}
