package com.xiaomi.migc.sdk.cache;

import com.xiaomi.migc.sdk.common.json.JsonUtil;
import com.xiaomi.migc.sdk.common.redis.RedisClusterClient;
import com.xiaomi.migc.sdk.model.vo.TokenVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceTokenCache {

    private static Logger logger = LoggerFactory.getLogger(ServiceTokenCache.class);
    private static final int expire_time = 3600 * 24 * 2;
    private static final String service_token_prefix = "account:st:";
    private static final String service_token_session_prefix = "account:st:session:";

    @Autowired
	private RedisClusterClient redisClient;

    public void cacheToken(long fuid, TokenVo vo) {
        String key = convertTokenKey(fuid, vo.getSession());
        String value = JsonUtil.json(vo);
        redisClient.setex(key, expire_time, value);
    }

    public void cacheSession(long fuid, long devAppId, String session) {
        String key = convertSessionKey(fuid,devAppId);
        redisClient.setex(key, expire_time, session);
    }

    public boolean isValidateSession(long fuid, long devAppId, String session) {
        if (StringUtils.isBlank(session)) {
            return false;
        }
        String key = convertSessionKey(fuid,devAppId);
        String value = redisClient.get(key);
        if(StringUtils.isNotBlank(value) && session.equals(value)) {
            return true;
        }
        return false;
    }

    private String convertSessionKey(long fuid, long devAppId) {
        StringBuilder sb = new StringBuilder();
        sb.append(service_token_session_prefix).append(fuid).append(":")
                .append(devAppId);
        return sb.toString();
    }

    private String convertTokenKey(long fuid, String session) {
        StringBuilder sb = new StringBuilder();
        sb.append(service_token_prefix).append(fuid).append(":").append(session);
        return sb.toString();
    }

}
