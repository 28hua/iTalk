package com.xiaomi.migc.sdk.common;

import com.xiaomi.miliao.zookeeper.EnvironmentType;
import com.xiaomi.miliao.zookeeper.ZKClient;
import com.xiaomi.miliao.zookeeper.ZKDataChangeListener;
import com.xiaomi.miliao.zookeeper.ZKFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * @author mujiawang
 * @date 2018/8/8
 * @Version 1.0
 */
public enum  OnOffUtils {

    INSTANCE;

    private Properties cacheOne = new Properties();

    private Properties cacheTwo = new Properties();


    private int cacheNo = 1;

    private final String configPath  = "/huyu/migc/bill/on-off";

    private final Logger logger = LoggerFactory.getLogger(OnOffUtils.class);

    private OnOffUtils() {
        initCache();
    }

    public boolean isOn(String key) {
        String value = null;
        if (cacheNo == 1) {
            value = cacheOne.getProperty(key);
        } else {
            value = cacheTwo.getProperty(key);
        }
        if ("on".equals(value)) {
            return true;
        }
        return false;
    }

    private void initCache(){
        EnvironmentType environmentType = ZKFacade.getZKSettings().getEnvironmentType();
        ZKClient zkClient = ZKFacade.getClient(environmentType);
        Properties config = zkClient.getData(Properties.class, configPath);
        cacheOne = config;
        zkClient.registerDataChanges(Properties.class, configPath, new ZKDataChangeListener<Properties>() {

            @SuppressWarnings({"rawtypes", "unchecked"})
            @Override
            public void onChanged(String s, Properties data) {
                long start = System.currentTimeMillis();
                logger.info("....... on-off zk config change start.......");
                synchronized (this) {
                    if (cacheNo==1) {
                        cacheTwo = data;
                        cacheNo = 2;
                    } else {
                        cacheOne = data;
                        cacheNo =1;
                    }
                }
                long end = System.currentTimeMillis();
                logger.info("....... on-off zk config change end, time spend is {}", end-start);
            }
        });
    }

}
