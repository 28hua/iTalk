package com.xiaomi.migc.sdk.biz;

import com.xiaomi.migc.sdk.exception.BizException;
import com.xiaomi.migc.sdk.model.vo.AccountVo;

import java.util.List;

/**
 * @author mujiawang
 * @date 2018/12/28
 * @Version 1.0
 */
public interface AccountBiz {

    public AccountVo getLastLoginAccount(long fuid, long devAppId, String imei) throws BizException;

    public void saveLastPlayedAccount(long fuid, long devAppId, long openId) throws BizException;

    public boolean verifyAccount(long openId, long fuid, long devAppId) throws BizException;

    public List<AccountVo> listAccounts(long fuid, long devAppId) throws BizException;

    public AccountVo getByThirdOpenId(String thirdOpenId, long devAppId, int thirdCode) throws BizException;
}
