package com.xiaomi.migc.sdk.biz;

import java.io.UnsupportedEncodingException;

import com.xiaomi.migc.sdk.cache.ServiceTokenCache;
import com.xiaomi.migc.sdk.common.SdkVersionUtils;
import com.xiaomi.migc.sdk.model.ServiceToken;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.migc.sdk.common.RandomUtils;
import com.xiaomi.migc.sdk.dao.ServiceTokenDAO;
import com.xiaomi.migc.sdk.model.vo.TokenVo;

@Service
public class TokenBiz {

	@Autowired
	ServiceTokenCache tokenCache;

	@Autowired
	private ServiceTokenDAO serviceTokenDAO;

	public TokenVo createServiceToken(long fuid, long xiaomiId, long devAppId, String sdkVersion) throws UnsupportedEncodingException {
		String sessionId = RandomUtils.getRandomStr(16);
        String key = RandomUtils.getRandomStr(16);
        String akey = RandomUtils.getRandomStr(16);
        String hexAkey = byte2hex(akey.getBytes("UTF-8"));
        long timestamp = System.currentTimeMillis();
        TokenVo vo = new TokenVo();
        vo.setKey(key);
        vo.setSession(sessionId);
        vo.setAkey(hexAkey);
        vo.setUid(fuid);
        vo.setT(timestamp);
        vo.setMid(xiaomiId);
        vo.setLastCheckAuthTime(timestamp);
        tokenCache.cacheToken(fuid, vo);
        tokenCache.cacheSession(fuid, devAppId, sessionId);
        if (StringUtils.isBlank(sdkVersion)) {
        	sdkVersion = "";
		}
        if(xiaomiId > 0 && !SdkVersionUtils.isCheckServiceToken(sdkVersion)) {
        	serviceTokenDAO.saveServiceToken(xiaomiId, vo);
        }
        return vo;
	}

	public boolean isValidate(long miId, long fuid, String session, String sdkVersion) {
		if (SdkVersionUtils.isCheckServiceToken(sdkVersion)) {
			return true;
		}
		ServiceToken token = serviceTokenDAO.getServiceToken(miId, fuid, session);
		if (token != null) {
			return true;
		}
		return false;
	}

	public boolean isValidateWithAppId(long fuid, long devAppId, String session, String sdkVersion) {
		if (!SdkVersionUtils.isCheckServiceToken(sdkVersion)) {
			return true;
		}
		return tokenCache.isValidateSession(fuid, devAppId, session);
	}
	
	
	public static String byte2hex(byte[] b) {
		String hs = "";
		String stmp = "";
		for (int n = 0; n < b.length; n++) {
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1) {
				hs = hs + "0" + stmp;
			} else {
				hs = hs + stmp;
			}
		}
		return hs.toUpperCase();
	}

}
