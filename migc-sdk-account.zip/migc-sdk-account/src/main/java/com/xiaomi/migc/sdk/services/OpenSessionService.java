package com.xiaomi.migc.sdk.services;

import com.google.protobuf.InvalidProtocolBufferException;
import com.xiaomi.huyu.blink.RpcInvocation;
import com.xiaomi.huyu.blink.ServiceResponse;
import com.xiaomi.huyu.blink.annotation.BlinkService;
import com.xiaomi.huyu.blink.annotation.Cmd;
import com.xiaomi.huyu.blink.utils.StringUtils;
import com.xiaomi.migc.sdk.biz.OpenSessionBiz;
import com.xiaomi.migc.sdk.common.RetCode;
import com.xiaomi.migc.sdk.model.pb.AccountS2S;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by jhw on 2017/5/20.
 */

@BlinkService
public class OpenSessionService {
    private Logger logger = LoggerFactory.getLogger(OpenSessionService.class);

    @Autowired
    private OpenSessionBiz openSessionBiz;

    @Cmd(id = 1, name = "migcsdk.account.createsession")
    public ServiceResponse createOpensession(RpcInvocation inv, byte[] data) {
        AccountS2S.SetOpenSessionRsp.Builder builder = AccountS2S.SetOpenSessionRsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            AccountS2S.SetOpenSessionReq request = AccountS2S.SetOpenSessionReq.parseFrom(data);

            Long openId = request.getOpenId();
            String session = request.getSession();
            String devAppId= request.getDevAppId();

            if (StringUtils.isEmpty(devAppId)) {
                openSessionBiz.genOpenSession(openId,session);
            }else {
                Long appId = Long.valueOf(devAppId);
                openSessionBiz.genOpenSession(openId,appId,session);
            }

            builder.setRetCode(RetCode.success.getCode());


        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        return response;
    }

    @Cmd(id = 1, name = "migcsdk.account.verifysession")
    public ServiceResponse verifyOpenSession(RpcInvocation inv, byte[] data) {
        AccountS2S.SetOpenSessionRsp.Builder builder = AccountS2S.SetOpenSessionRsp.newBuilder();
        ServiceResponse response = inv.getResponse();

        try {
            AccountS2S.SetOpenSessionReq request = AccountS2S.SetOpenSessionReq.parseFrom(data);

            Long openId = request.getOpenId();
            String session = request.getSession();
            String devAppId= request.getDevAppId();

            boolean result = false;
            if (StringUtils.isEmpty(devAppId)) {
                result = openSessionBiz.isValidate(openId,session);
            }else {
                Long appId = Long.valueOf(devAppId);
                result = openSessionBiz.isValidate(openId,appId,session);
            }

            if (result) {
                builder.setRetCode(RetCode.success.getCode());
            }else{
                builder.setRetCode(RetCode.serviceTokenExpiredError.getCode());
            }



        } catch (Exception e) {
            builder.setRetCode(RetCode.systemError.getCode());
            logger.error("", e);
        }
        response.setBody(builder.build().toByteArray());
        return response;
    }
}
