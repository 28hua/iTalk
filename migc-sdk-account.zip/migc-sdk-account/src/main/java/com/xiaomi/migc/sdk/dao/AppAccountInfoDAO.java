package com.xiaomi.migc.sdk.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.xiaomi.migc.sdk.model.AppAccountInfo;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.SQLParam;
import net.paoding.rose.jade.annotation.ShardBy;
import net.paoding.rose.jade.annotation.UseMaster;

/**
 * 游戏帐户数据库操作类
 * @author jhw
 *
 */
@DAO(catalog="migc_bill_manageruser")
public interface AppAccountInfoDAO{
	
	public static final String table_fields = "app_account_id,xiaomi_id,app_id,app_account_name,account_status,last_played_time,create_time,update_time,app_account_alias, account_type";
	
	/**
	 * 保存游戏帐户
	 * @param appAccountInfo
	 * @throws DataAccessException
	 */
	
	@UseMaster
	@SQL("insert into app_account_info (app_account_id ,xiaomi_id,app_id,app_account_name,account_status,last_played_time,create_time,update_time,app_account_alias,account_type) values"
			+ " (:i.appAccountId,:i.xiaomiId,:i.appId,:i.appAccountName,:i.accountStatus,:i.lastPlayedTime,:i.createTime,:i.updateTime,:i.appAccountAlias,:i.accountType)")
	public void saveAppAccountInfo(@ShardBy long xiaomiId,@SQLParam("i")AppAccountInfo appAccountInfo);
	

	/**
	 * 根据游戏id和用户id查询游戏帐户列表
	 * @param appId
	 * @param userId
	 * @return
	 * @throws DataAccessException
	 */
	@UseMaster
	@SQL("select " + table_fields + " from app_account_info where xiaomi_id = :xiaomiId and app_id = :appId and account_status = 1")
	public List<AppAccountInfo> findAppAccountInfosByAppAndXiaomiId(@ShardBy @SQLParam("xiaomiId")long xiaomiId,@SQLParam("appId")long appId);
	
	@UseMaster
	@SQL("select " + table_fields + " from app_account_info where xiaomi_id = :xiaomiId and app_id = :appId and account_status = 1")
	public List<AppAccountInfo> listAppAccountByAppIdAndXiaomiId(@SQLParam("appId")long appId, @ShardBy @SQLParam("xiaomiId")long xiaomiId);

	@UseMaster
	@SQL("select " + table_fields + " from app_account_info where  app_account_alias = :alias and app_id = :appId and account_status=1 limit 1")
	public AppAccountInfo getAppAccountInfoByAppAndAlias(@ShardBy long xiaomiId,@SQLParam("alias")long appAccountAlias,@SQLParam("appId") long appId);

	@UseMaster
	@SQL("select " + table_fields + " from app_account_info where xiaomi_id = :id and app_id = :appId and app_account_alias = :alias and account_status = 1 limit 1")
	AppAccountInfo getByXiaomiIdAndAppIdAndAlias(@ShardBy @SQLParam("id") long xiaomiId,
												 @SQLParam("appId") long appId,
												 @SQLParam("alias") long appAccountAlias);
}
