package com.xiaomi.migc.sdk.dao;

import com.xiaomi.migc.sdk.model.App;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.SQLParam;
import net.paoding.rose.jade.annotation.UseMaster;

@DAO(catalog="migc_bill_adminuser")
public interface AppExtDAO {

	 public static final String table_fields = "ext_id,game_name,package_name,app_key,ext_status,status,allow_xiaohao,dev_app_id ,toolbar_config,is_display_toolbar,is_controll,app_type,login_account_type,is_display_loginbar";
     
     @UseMaster
     @SQL("select " + table_fields + " from app_ext where dev_app_id = :id")
     public App getAppExtInfoByDevAppId(@SQLParam("id") long devAppId);
}
