package com.xiaomi.migc.sdk.common.json;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {
	private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);
	private static final ObjectMapper mapper = new ObjectMapper();
	
	public static String json(Object data) {
        try {
            String json = mapper.writeValueAsString(data);
            return json;

        } catch (IOException e) {
            logger.error("json.fail", e);
            return "";
        }
    }

    public static <T> T parseJson(String value, Class<T> tClass) {
	    T t = null;
        if (StringUtils.isNotBlank(value)) {
            try {
                t = mapper.readValue(value, tClass);
            } catch (IOException e) {
                logger.error("parsejson.fail", e);
            }
        }

        return t;
    }
}
