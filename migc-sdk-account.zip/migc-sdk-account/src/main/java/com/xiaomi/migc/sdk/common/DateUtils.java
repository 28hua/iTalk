package com.xiaomi.migc.sdk.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * 日期操作工具类
 * @author hw
 *
 */
public class DateUtils {
	private static final String DATE_TIME_FORMAT = "yyyyMMddHHmmss";

	public static String getBeforeDate() {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		return format.format(calendar.getTime());
	}

	public static String format(Date date, String patternModel) {
		SimpleDateFormat format = new SimpleDateFormat(patternModel);
		return format.format(date);
	}

	public static String formatDateTime(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);

		return sdf.format(date);
	}

	public static Date convertStringToDate(String dateStr) {
		DateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
		Date date = null;
		try {
			date = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static Date convertStringToDate(String dateStr,String formatModel) {
		DateFormat sdf = new SimpleDateFormat(formatModel);
		Date date = null;
		try {
			date = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public static String getBeforeDate(int beforeDays, String formatModel) {
		SimpleDateFormat format = new SimpleDateFormat(formatModel);

		beforeDays = Math.abs(beforeDays);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -beforeDays);
		return format.format(calendar.getTime());
	}

	/**
	 * 格式化日期
	 * 
	 * @param date
	 *            日期
	 * @param formatModel
	 *            日期格式
	 * @return
	 */
	public static String formateDate(Date date, String formatModel) {

		if (date != null && !StringUtils.isEmpty(formatModel)) {

			SimpleDateFormat sdf = new SimpleDateFormat(formatModel);

			return sdf.format(date);
		}
		return null;
	}
	
	/**
	 * 获取指定时间前几个小时的时间
	 * 
	 * @param date
	 * @param hours
	 * @return
	 */
	public static String getHoursAgo(Date date, int hours) {
		long time = date.getTime() - 1000*60*60*hours;
        return new SimpleDateFormat("yyyyMMddHH").format(time);
	}
	
	public static Date getBeforeDate(int days) {
		days = Math.abs(days);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -days);
		return calendar.getTime();
	}
	
	public static void main(String[] args){
		//1493567999000
		Date d = new Date(1496246399000l);
		System.out.println(convertStringToDate("20170531235959").getTime());
	}
}
