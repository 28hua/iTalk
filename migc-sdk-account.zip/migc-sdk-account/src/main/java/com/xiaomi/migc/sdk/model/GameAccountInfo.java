package com.xiaomi.migc.sdk.model;

import com.xiaomi.migc.sdk.common.Constants;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

public class GameAccountInfo {


    private long id;

    private long fuid;

    private long openId;

    private long devAppId;

    private int type = 1;

    private int accountType = Constants.ACCOUNT_TYPE_DEFAULT;

    private int status = Constants.ACCOUNT_STATUS_ON;

    private String deviceNo = "";

    private String accountName = Constants.DEFAULT_ACCOUNT_NAME;

    private String channel = "";

    private Date lastLoginTime;

    private Date bindingTime;

    private Date createTime;

    private Date updateTime;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getFuid() {
        return fuid;
    }

    public void setFuid(long fuid) {
        this.fuid = fuid;
    }

    public long getOpenId() {
        return openId;
    }

    public void setOpenId(long openId) {
        this.openId = openId;
    }

    public long getDevAppId() {
        return devAppId;
    }

    public void setDevAppId(long devAppId) {
        this.devAppId = devAppId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDeviceNo() {
        return deviceNo;
    }

    public void setDeviceNo(String deviceNo) {
        this.deviceNo = deviceNo;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public Date getBindingTime() {
        return bindingTime;
    }

    public void setBindingTime(Date bindingTime) {
        this.bindingTime = bindingTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public GameAccountInfo() {

    }

    public GameAccountInfo(long devAppId, String deviceNo, long openId, String channel) {
        this.fuid = -1;
        this.type = 0;
        this.devAppId = devAppId;
        if (StringUtils.isNotBlank(deviceNo)) {
            this.deviceNo = deviceNo;
        }
        this.openId = openId;
        if (StringUtils.isNotBlank(channel)) {
            this.channel = channel;
        }
        Date date = new Date();
        this.createTime = date;
        this.lastLoginTime = date;
        this.updateTime = date;
    }

}
