package com.xiaomi.migc.sdk.common;

public enum RetCode {

	success(200,"成功"),
	systemError(1001,"系统错误"),
	dbError(1002,"数据库错误"),
	redisError(1003,"redis处理错误"),
	httpError(1004,"http请求错误"),
	replayRequestError(1005,"重复请求"),
	jsonParseError(1006,"解析json错误"),
	rsaError(1007,"RSA签名错误"),
	reponseEmpty(1008,"查询结果为空"),
	aesError(1009,"AES加密错误"),
	invaildError(1010,"非法的请求"),
	paramError(1011,"参数错误"),
	setUserInfoError(1012,"设置用户错误"),


	paramNoInputError(1501,"未输入请求参数"),
	ipSignatureError(1502,"IP鉴权错误"),
	msgIdError(1503,"消息号错误"),
	senderError(1504,"网元错误"),
	paramAppIdError(1515,"APPID错误"),
	paramUidError(1516,"内部用户编号错误(uid错误)"),
	channelIdError(1517,"渠道号错误"),
	accountStatusError(1518,"账户状态错误"),
	apkNameError(1526,"apkName错误"),
	apkSignError(1527,"apkSign错误"),
	sdkVersionCodeError(1528,"sdkVersionCode错误"),
	accessTokenError(1534,"accessToken错误"),
	appVerifyError(1546,"app已下线"),
	noConfigBillInfoError(1549,"未配置计费信息，开发者站和计费系统数据不同步"),
	
	serviceTokenExpiredError(4002,"serviceToken过期"),
	getServiceTokenError(4003,"获取serviceToken失败"),
	verifyServiceTokenError(4004,"验证serviceToken失败"),

	VERIFY_ACCOUNT_INFO_ERROR(5001, "验证错误"),

	getfuidByThirdOpenIdError(6001, "获取fuid错误"),

	forbiddenChannel(7001, "当前渠道被禁止"),
	loginTimes5MinError(7002, "5分钟内登录次数超过10次");

	
	private int code;
	private String message;
	
	private RetCode(int code, String message){
		this.code = code;
		this.message = message;
	}
	public int getCode() {
		return code;
	}
	public String getMessage() {
		return message;
	}
}
