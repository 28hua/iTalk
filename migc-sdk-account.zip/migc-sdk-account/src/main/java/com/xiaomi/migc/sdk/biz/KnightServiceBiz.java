package com.xiaomi.migc.sdk.biz;

import com.google.protobuf.InvalidProtocolBufferException;
import com.xiaomi.huyu.blink.client.*;
import com.xiaomi.huyu.blink.client.model.BlinkResponse;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;
import com.xiaomi.migc.sdk.model.pb.KnightS2S;

import com.xiaomi.miliao.zookeeper.EnvironmentType;
import com.xiaomi.miliao.zookeeper.ZKFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service
public class KnightServiceBiz {

    private Logger logger = LoggerFactory.getLogger(FuidBiz.class);

    private static final int USER_SET_L5_CMD_ID = 1017;
    private static final int USER_SET_HEARDER_ID = 1017;
    private static final int timeout = 300;
    //private static final IBlinkClient blinkClient = BlinkClientFactory.getBlinkClient("knights.user");
    private static IBlinkClient blinkClient = null;
    private static final EnvironmentType envType = ZKFacade.getZKSettings().getEnvironmentType();

    static{
        blinkClient = envType.equals(EnvironmentType.STAGING)
                ? BlinkClientFactory.getBlinkClient("knights.user") :
                BlinkClientFactory.getBlinkClient("knights.user",EnvironmentType.C3);
    }


    public KnightS2S.SetUserInfoIfNotExistRsp setKnightUserInfo(AccountS2C.SetUserInfoToGameCenterReq req) {

        long fuid = req.getFuid();
        String nickName = req.getNickname();
        int sex = req.getSex();
        String imei = req.getImei();
        String url = req.getAvatarUrl();
        boolean autoLogin = req.getAutoLogin();

        KnightS2S.UserInfo userInfo = KnightS2S.UserInfo.newBuilder().setUuid(fuid).setNickname(nickName).setSex(sex).build();

        KnightS2S.SetUserInfoIfNotExistReq request = KnightS2S.SetUserInfoIfNotExistReq.newBuilder()
                .setAutoLogin(autoLogin).setAvatarUrl(url).setImei(imei).setUuid(fuid)
                .setUserInfo(userInfo).build();
        try {
            Command command = new Command(USER_SET_HEARDER_ID, USER_SET_L5_CMD_ID);

            BlinkResponse response = blinkClient.invoke(command, request.toByteArray(), timeout);
            if (response.isSuccess()) {

                try {
                    KnightS2S.SetUserInfoIfNotExistRsp setUserInfoRsp =
                            KnightS2S.SetUserInfoIfNotExistRsp.parseFrom(response.getBody());

                    if (setUserInfoRsp != null) {
                        int errCode = setUserInfoRsp.getRetCode();
                        String errMsg = setUserInfoRsp.getErrMsg();
                        logger.info("The GetUserInfo response code : {},errMsg : {}", errCode, errMsg);
                        return setUserInfoRsp;
                    }
                } catch (InvalidProtocolBufferException e) {

                    logger.info("The SetUserInfo response is error! ", e);
                }

            } else {
                logger.info("The SetUserInfo response is error! ");
            }
        }catch (Exception e){
            logger.info("Get blink ie error! ", e);
        }

        return null;
    }
}
