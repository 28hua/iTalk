package com.xiaomi.migc.sdk.common;

import com.xiaomi.migc.sdk.model.GameIdMapping;
import com.xiaomi.miliao.zookeeper.EnvironmentType;
import com.xiaomi.miliao.zookeeper.ZKClient;
import com.xiaomi.miliao.zookeeper.ZKDataChangeListener;
import com.xiaomi.miliao.zookeeper.ZKFacade;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ConcurrentHashMap;

public enum  MasterAppIdUtils {


    INSTANCE;

    private ConcurrentHashMap<Long, GameIdMapping> cacheOne = new ConcurrentHashMap<Long, GameIdMapping>();

    private ConcurrentHashMap<Long, GameIdMapping> cacheTwo = new ConcurrentHashMap<Long, GameIdMapping>();

    private int cacheNo = 1;

    private final String configPath  = "/huyu/migc/bill/master_app_id";

    private final Logger logger = LoggerFactory.getLogger(MasterAppIdUtils.class);
    private MasterAppIdUtils() {
        initCache();
    }

    public long getDevAppId(long devAppId) {
        GameIdMapping mapping = null;
        if (cacheNo == 1) {
            mapping = cacheOne.get(Long.valueOf(devAppId));

        } else {
            mapping = cacheTwo.get(Long.valueOf(devAppId));
        }

        if (mapping == null) {
            return devAppId;
        } else {
            return mapping.getDevAppId();
        }
    }

    public GameIdMapping getGameIdMapping(long devAppId) {
        GameIdMapping mapping = null;
        if (cacheNo == 1) {
            mapping = cacheOne.get(Long.valueOf(devAppId));

        } else {
            mapping = cacheTwo.get(Long.valueOf(devAppId));
        }
        return mapping;
    }


    private void initCache(){
        EnvironmentType environmentType = ZKFacade.getZKSettings().getEnvironmentType();
        ZKClient zkClient = ZKFacade.getClient(environmentType);
        String config = zkClient.getData(String.class, configPath);
        updateCache(config, cacheOne);
        zkClient.registerDataChanges(String.class, configPath, new ZKDataChangeListener<String>() {

            @SuppressWarnings({"rawtypes", "unchecked"})
            @Override
            public void onChanged(String s, String data) {
                long start = System.currentTimeMillis();
                logger.info("....... master app id zk config change start.......");
                ConcurrentHashMap<Long, GameIdMapping> map = new ConcurrentHashMap();
                updateCache(data, map);
                synchronized (this) {
                    if (cacheNo==1) {
                        cacheTwo = map;
                        cacheNo = 2;
                    } else {
                        cacheOne = map;
                        cacheNo =1;
                    }
                }
                long end = System.currentTimeMillis();
                logger.info("....... master app id zk config change end, time spend is {}", end-start);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void updateCache(String config, ConcurrentHashMap<Long, GameIdMapping> map) {
        try {
            Document document = DocumentHelper.parseText(config);
            Element root = document.getRootElement();
            java.util.List<Element> elements = root.elements();
            for (Element element : elements) {
                GameIdMapping mapping = new GameIdMapping();
                String devAppId = (String) element.element("dev_app_id").getData();
                String masterExtId = (String) element.element("master_ext_id").getData();
                String masterDevAppId = (String) element.element("master_dev_app_id").getData();
                String slaveExtId = (String) element.element("slave_ext_id").getData();
                String slaveDevAppId = (String) element.element("slave_dev_app_id").getData();
                mapping.setMasterExtId(Long.parseLong(masterExtId));
                mapping.setMasterDevAppId(Long.parseLong(masterDevAppId));
                mapping.setSlaveExtId(Long.parseLong(slaveExtId));
                mapping.setSlaveDevAppId(Long.parseLong(slaveDevAppId));
                mapping.setDevAppId(Long.parseLong(devAppId));
                map.put(Long.valueOf(slaveDevAppId), mapping);
                map.put(Long.valueOf(masterDevAppId), mapping);
            }
        } catch (Exception e) {
            System.out.println(e);
            logger.error("", e);
        }
    }

}
