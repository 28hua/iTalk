package com.xiaomi.migc.sdk.exception;

import com.xiaomi.migc.sdk.common.RetCode;

/**
 * @author mujiawang
 * @date 2018/12/28
 * @Version 1.0
 */
public class BizException extends Exception{

    private RetCode retCode;

    public BizException(RetCode retCode) {
        super(retCode.getMessage());
        this.retCode = retCode;
    }

    public BizException(RetCode retCode, String message) {
        super(message);
        this.retCode = retCode;
    }

    public BizException(RetCode retCode, Throwable cause) {
        super(retCode.getMessage(), cause);
        this.retCode = retCode;
    }

    public BizException(RetCode retCode, String message, Throwable cause) {
        super(message, cause);
        this.retCode = retCode;
    }

    public RetCode getRetCode() {
        return retCode;
    }

    public void setRetCode(RetCode retCode) {
        this.retCode = retCode;
    }
}
