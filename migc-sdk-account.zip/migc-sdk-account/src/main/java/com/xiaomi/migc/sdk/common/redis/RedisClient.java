package com.xiaomi.migc.sdk.common.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class RedisClient {

	private JedisPool jedisPool;
	
	public RedisClient() {
	}
	
	public void set(String key, String value) {
		
        Jedis jedis = getRedisConnection();
        try {
            jedis.set(key, value);
        } finally {
            closeRedisConnection(jedis);
        }
	}
	
	public String get(String key) {
		String result = "";
		Jedis jedis = getRedisConnection();
        try {
            result = jedis.get(key);
        } finally {
            closeRedisConnection(jedis);
        }
        
		return result;
	}
	
	public void setex(String key, int seconds, String value) {
		
		Jedis jedis = getRedisConnection();
        try {
            jedis.setex(key, seconds, value);
        } finally {
            closeRedisConnection(jedis);
        }
	}
	
	
	public Jedis getRedisConnection() {
        Jedis jedis = jedisPool.getResource();
        return jedis;
    }

    /**
     * 鍏抽棴redis杩炴帴
     * 
     * @param jedis
     */
    public void closeRedisConnection(Jedis jedis) {
        if (jedis != null) {
            jedisPool.returnResource(jedis);
        }
    }

	public JedisPool getJedisPool() {
		return jedisPool;
	}

	public void setJedisPool(JedisPool jedisPool) {
		this.jedisPool = jedisPool;
	}
}
