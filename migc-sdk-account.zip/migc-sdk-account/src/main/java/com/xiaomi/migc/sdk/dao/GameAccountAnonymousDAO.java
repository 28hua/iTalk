package com.xiaomi.migc.sdk.dao;

import com.xiaomi.migc.sdk.model.GameAccountAnonymous;
import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.SQLParam;
import net.paoding.rose.jade.annotation.UseMaster;

@DAO(catalog = "migc_bill_gameuser")
public interface GameAccountAnonymousDAO {

    String INSERT_COLUMN = "open_id, dev_app_id, device_no, create_time ";

    @UseMaster
    @SQL("select " +INSERT_COLUMN+ " from game_account_anonymous where dev_app_id = :devAppId and device_no = :deviceNo ")
    GameAccountAnonymous getAnonymousAccount(@SQLParam("devAppId") long devAppId, @SQLParam("deviceNo") String deviceNo);

    @UseMaster
    @SQL("insert into game_account_anonymous (" +INSERT_COLUMN+ ") values (:i.openId, :i.devAppId, :i.deviceNo, :i.createTime)")
    void insert(@SQLParam("i") GameAccountAnonymous anonymous);
}
