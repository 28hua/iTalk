package com.xiaomi.migc.sdk.biz;


import com.xiaomi.migc.sdk.model.GameAccountAnonymous;

public interface AnonymousAccountBiz {

    /**
     * 获取游客账户信息
     * @param devAppId
     * @param deviceNo
     * @param channel
     * @return
     */
    GameAccountAnonymous getAnonymousAccount(long devAppId, String deviceNo, String channel);

    /**
     * 获取游客账户信息
     * @param devAppId
     * @param deviceNo
     * @param channel
     * @return
     */
    GameAccountAnonymous getAnonymousAccountV2(long devAppId, String deviceNo, String channel);

}
