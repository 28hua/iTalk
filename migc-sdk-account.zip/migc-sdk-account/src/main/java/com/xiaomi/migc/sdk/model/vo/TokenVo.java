package com.xiaomi.migc.sdk.model.vo;

public class TokenVo {

	private String session;
	private String key;
	private long uid;
	private long t; //时间戳
	private String nickName;
	private String akey;//aes加密秘钥
	private long lastCheckAuthTime;
	private long mid;
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public long getUid() {
		return uid;
	}
	public void setUid(long uid) {
		this.uid = uid;
	}
	public long getT() {
		return t;
	}
	public void setT(long t) {
		this.t = t;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getAkey() {
		return akey;
	}
	public void setAkey(String akey) {
		this.akey = akey;
	}
	public long getLastCheckAuthTime() {
		return lastCheckAuthTime;
	}
	public void setLastCheckAuthTime(long lastCheckAuthTime) {
		this.lastCheckAuthTime = lastCheckAuthTime;
	}
	public long getMid() {
		return mid;
	}
	public void setMid(long mid) {
		this.mid = mid;
	}
}
