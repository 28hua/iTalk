package com.xiaomi.migc.sdk.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.migc.sdk.cache.OpenSessionCache;
import com.xiaomi.migc.sdk.common.RandomUtils;

@Service
public class OpenSessionBiz {

	@Autowired
	private OpenSessionCache openSessionCache;
	
	public String genOpenSession(Long openId, Long devAppId) {
		String session = RandomUtils.getRandomStr(16);
		openSessionCache.cacheOpenSession(openId, devAppId, session);
		return session;
	}

	public String genOpenSession(Long openId, Long devAppId, String session) {
		openSessionCache.cacheOpenSession(openId, devAppId, session);
		return session;
	}

	public String genOpenSession(Long openId, String session) {
		openSessionCache.cacheOpenSession(openId, session);
		return session;
	}


	public boolean isValidate(Long openId, Long devAppId, String session) {
		return openSessionCache.isValidateSession(openId, devAppId, session);
	}

	public boolean isValidate(Long openId, String session) {
		return openSessionCache.isValidateSession(openId, session);
	}
}
