package com.xiaomi.migc.sdk.common;

import org.apache.commons.lang3.StringUtils;

/**
 * @author mujiawang
 * @date 2018/12/20
 * @Version 1.0
 */
public class SdkVersionUtils {

    private static final String check_st_min_ver = "SDK_TY_5.1.5";

    private static final String check_fuid_token_min_ver = "SDK_TY_4.9.58";

    public static int compareTo(String ver1, String ver2) {
        String[] arr1 = ver1.split("_");
        String[] arr2 = ver2.split("_");
        return arr1[arr1.length-1].compareTo(arr2[arr2.length-1]);
    }

    public static boolean isCheckServiceToken(String version) {
        if (compareTo(check_st_min_ver, version) <= 0) {
            return true;
        }
        return false;
    }

    public static boolean isCheckFuidToken(String sdkVersion) {
        if (compareTo(check_fuid_token_min_ver, sdkVersion) <= 0) {
            return true;
        }
        return false;
    }

    public static boolean isMinGameVersion(String sdkVersion) {
        if (StringUtils.isNotBlank(sdkVersion) && sdkVersion.startsWith("MINI_GAME_")) {
            return true;
        }
        return false;
    }

    public static boolean isNotCheckAccount(String sdkVersion) {
        if (StringUtils.isNotBlank(sdkVersion) &&
                (sdkVersion.startsWith("SDK_VISITOR_") || sdkVersion.startsWith("SDK_AWPAY_") ||
                        sdkVersion.startsWith("SDK_MIXPAY_") || sdkVersion.startsWith("SDK_PROXY_") ||
                        sdkVersion.startsWith("SDK_UCASHIER_") || sdkVersion.startsWith("SDK_MIBOX_") ||
                        sdkVersion.startsWith("server_") || sdkVersion.startsWith("MINI_GAME_"))) {
            return true;
        }
        return false;
    }


    public static void main(String[] args) {
        System.out.println(SdkVersionUtils.isCheckServiceToken("SDK_TY_5.1.5"));
    }
}
