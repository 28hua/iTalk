package com.xiaomi.migc.sdk.biz.impl;

import com.xiaomi.migc.sdk.biz.AnonymousAccountBiz;
import com.xiaomi.migc.sdk.biz.FuidBiz;
import com.xiaomi.migc.sdk.common.DateUtils;
import com.xiaomi.migc.sdk.dao.GameAccountAnonymousDAO;
import com.xiaomi.migc.sdk.dao.GameAccountInfoDAO;
import com.xiaomi.migc.sdk.dao.OpenIdentificationDAO;
import com.xiaomi.migc.sdk.model.GameAccountAnonymous;
import com.xiaomi.migc.sdk.model.GameAccountInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.Date;

@Service
public class AnonymousAccountBizImpl implements AnonymousAccountBiz {

    @Autowired
    GameAccountInfoDAO gameAccountInfoDAO;

    @Autowired
    OpenIdentificationDAO openIdentificationDAO;

    @Autowired
    GameAccountAnonymousDAO gameAccountAnonymousDAO;

    @Autowired
    FuidBiz fuidBiz;

    private static final int ID_CYCLE = 10000000;

    private static final String DF = "yyyyMMdd";

    private static final String SF = "00000000";

    @Override
    @Deprecated
    public GameAccountAnonymous getAnonymousAccount(long devAppId, String deviceNo, String channel) {
        GameAccountAnonymous accountAnonymous = gameAccountAnonymousDAO.getAnonymousAccount(devAppId, deviceNo);
        if (accountAnonymous == null) {
            long openId = genOpenId();

            GameAccountInfo accountInfo = new GameAccountInfo(devAppId, deviceNo, openId, channel);
            accountAnonymous = new GameAccountAnonymous();
            accountAnonymous.setOpenId(openId);
            accountAnonymous.setDevAppId(devAppId);
            accountAnonymous.setDeviceNo(deviceNo);
            accountAnonymous.setCreateTime(accountInfo.getCreateTime());
            gameAccountInfoDAO.insert(openId, accountInfo);
            gameAccountAnonymousDAO.insert(accountAnonymous);
        }
        return accountAnonymous;
    }

    @Override
    public GameAccountAnonymous getAnonymousAccountV2(long devAppId, String deviceNo, String channel) {
        GameAccountAnonymous accountAnonymous = gameAccountAnonymousDAO.getAnonymousAccount(devAppId, deviceNo);
        if (accountAnonymous == null) {

            long fuid = fuidBiz.getFuidByThirdOpenId(deviceNo, 19);
            if (fuid >0L) {
                long openId = genOpenId();
                GameAccountInfo accountInfo = new GameAccountInfo(devAppId, deviceNo, openId, channel);
                accountInfo.setType(1);
                accountInfo.setFuid(fuid);
                accountInfo.setBindingTime(accountInfo.getCreateTime());
                accountAnonymous = new GameAccountAnonymous();
                accountAnonymous.setOpenId(openId);
                accountAnonymous.setDevAppId(devAppId);
                accountAnonymous.setDeviceNo(deviceNo);
                accountAnonymous.setCreateTime(accountInfo.getCreateTime());
                accountAnonymous.setFuid(fuid);
                gameAccountInfoDAO.insert(openId, accountInfo);
                gameAccountInfoDAO.insertBindingByInfo(fuid, accountInfo);
                gameAccountAnonymousDAO.insert(accountAnonymous);
            }

        } else {
            GameAccountInfo accountInfo = gameAccountInfoDAO.getAccountInfo(accountAnonymous.getOpenId(), devAppId);
            if (accountInfo.getType() == 0 && accountInfo.getFuid() <=0L) {
                long fuid = fuidBiz.getFuidByThirdOpenId(deviceNo, 19);
                if (fuid >0L) {
                    accountInfo.setType(1);
                    accountInfo.setFuid(fuid);
                    Date updateTime = new Date();
                    accountInfo.setUpdateTime(updateTime);
                    accountInfo.setBindingTime(updateTime);
                    gameAccountInfoDAO.updateAnonymousFuid(accountInfo.getOpenId(), devAppId, fuid, updateTime);
                    gameAccountInfoDAO.insertBindingByInfo(fuid, accountInfo);
                    accountAnonymous.setFuid(fuid);
                }
            } else {
                accountAnonymous.setFuid(accountInfo.getFuid());
            }
        }
        return accountAnonymous;
    }

    private Long genOpenId() {
        Date date = new Date();
        StringBuilder sb = new StringBuilder();
        sb.append(DateUtils.format(date, DF));
        // 读数据库表，获取openid后六位
        long idInc = openIdentificationDAO.generateOpenId();

        long id = idInc % ID_CYCLE;

        DecimalFormat df = new DecimalFormat(SF);
        sb.append(df.format(id));
        return Long.valueOf(sb.toString());
    }

}
