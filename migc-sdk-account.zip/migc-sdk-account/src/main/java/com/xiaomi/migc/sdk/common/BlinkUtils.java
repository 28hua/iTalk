package com.xiaomi.migc.sdk.common;

import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.huyu.blink.client.BlinkClient;
import com.xiaomi.huyu.blink.client.BlinkClientFactory;
import com.xiaomi.huyu.blink.client.ClientFactory;
import com.xiaomi.huyu.blink.client.Command;
import com.xiaomi.huyu.blink.client.Config;
import com.xiaomi.huyu.blink.client.IBlinkClient;
import com.xiaomi.huyu.blink.client.model.BlinkResponse;

public class BlinkUtils {

	private static Logger logger = LoggerFactory.getLogger(BlinkUtils.class);
	private static ConcurrentHashMap<String, Config> blinkConfigs = new ConcurrentHashMap<String, Config>();
	private static final int timeout = 300;

	public static Config getBlinkConfigByL5ModId(int l5ModelId) {
		Config blinkConfig = blinkConfigs.get(String.valueOf(l5ModelId));
		if (blinkConfig == null) {
			blinkConfig = new Config(l5ModelId);
			blinkConfig.setConnectionPoolSize(50);
			blinkConfig.setEnableL5RoutingPolicy(true);
			Config tmp = blinkConfigs.putIfAbsent(String.valueOf(l5ModelId), blinkConfig);
			if (tmp != null) {
				blinkConfig = tmp;
			}
		}
		return blinkConfig;
	}

	public static byte[] invokeBlinkService(int l5ModelId, int cmdId, byte[] requestData) {
		BlinkClient blinkClient = ClientFactory.getInstance(getBlinkConfigByL5ModId(l5ModelId));
		Command command = new Command(cmdId, cmdId);

		BlinkResponse response = blinkClient.invoke(command, requestData, timeout);
		if (!response.isSuccess()) {
			logger.info("invoke blink service [" + l5ModelId + "] send faile " + response.getClientErrorCode());
			return null;
		}
		if (!response.serverIsSuccess()) {
			logger.info(
					"invoke blink service [" + l5ModelId + "] server not return 0 " + response.getServerErrorCode());
			return null;
		}
		return response.getBody();
	}

	public static byte[] invoke(String categoryName, int cmdId, byte[] request) {
		IBlinkClient blinkClient = BlinkClientFactory.getBlinkClient(categoryName);
		Command command = new Command(cmdId, cmdId);
		BlinkResponse response = blinkClient.invoke(command, request);
		if (!response.isSuccess()) {
			logger.info("invoke blink service [" + categoryName + "] send fail " + response.getClientErrorCode());
			return null;
		}
		if (!response.serverIsSuccess()) {
			logger.info(
					"invoke blink service [" + categoryName + "] server not return 0 " + response.getServerErrorCode());
			return null;
		}
		return response.getBody();
	}
}
