package com.xiaomi.migc.sdk.dao;

import com.xiaomi.migc.sdk.model.GameAccountInfo;
import net.paoding.rose.jade.annotation.*;

import java.util.Date;

@DAO(catalog = "migc_bill_gameuser")
public interface GameAccountInfoDAO {

    String TABLE_NAME = "game_account_info";

    String INSERT_COLUMN = "fuid, open_id, dev_app_id, type, account_type, status, device_no, account_name, channel, last_login_time, binding_time, create_time, update_time ";

    @UseMaster
    @SQL("insert into game_account_info (" +INSERT_COLUMN
            +") values (:i.fuid, :i.openId, :i.devAppId, :i.type, :i.accountType, :i.status, :i.deviceNo, :i.accountName, :i.channel, :i.lastLoginTime, :i.bindingTime, :i.createTime, :i.updateTime)")
    void insert(@ShardBy long openId, @SQLParam("i") GameAccountInfo info);

    @SQL("select " +INSERT_COLUMN+ " from game_account_info where open_id=:openId and dev_app_id=:devAppId and status =1")
    GameAccountInfo getAccountInfo(@ShardBy @SQLParam("openId") long openId,
                               @SQLParam("devAppId") long devAppId);

    @SQL("update game_account_info set fuid = :fuid, type=1, update_time=:updateTime, binding_time=:updateTime where open_id=:openId and dev_app_id=:devAppId and type=0")
    void updateAnonymousFuid(@ShardBy @SQLParam("openId") long openId,
                             @SQLParam("devAppId") long devAppId,
                             @SQLParam("fuid") long fuid,
                             @SQLParam("updateTime") Date updateTime);

    String B_INSERT_COLUMN = "fuid, open_id, dev_app_id, account_type, status, account_name, last_login_time, binding_time ";

    @UseMaster
    @SQL("insert into game_account_binding (" +B_INSERT_COLUMN
            +") values (:i.fuid, :i.openId, :i.devAppId, :i.accountType, :i.status, :i.accountName, :i.lastLoginTime, :i.bindingTime)")
    void insertBindingByInfo(@ShardBy long fuid, @SQLParam("i") GameAccountInfo info);

}
