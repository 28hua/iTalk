package com.xiaomi.migc.sdk.biz;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.xiaomi.migc.sdk.common.BlinkUtils;
import com.xiaomi.migc.sdk.common.RetCode;
import com.xiaomi.migc.sdk.common.PropUtils;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;
import com.xiaomi.migc.sdk.model.pb.UserChannelS2S;

@Service
public class UserChannelBiz {
	private static Logger logger = LoggerFactory.getLogger(UserChannelBiz.class);
	private static final int set_channel_cmd_id = 1002;

	public String setUserChannelForAnonymous(AccountS2C.AnonymousLoginV2Req req, long fuid, int retCode) {
		String ownerChannel = "";
		try {
			if (RetCode.success.getCode() == retCode && StringUtils.isNotBlank(req.getCurrentChannel())
					&& StringUtils.isNotBlank(req.getUa()) && req.getDevAppId() > 0L && fuid > 0L) {

				UserChannelS2S.SetChannelReq.Builder builder = UserChannelS2S.SetChannelReq.newBuilder()
						.setChannel(req.getCurrentChannel()).setDevAppId(req.getDevAppId())
						.setFuid(fuid);
				if(StringUtils.isNotBlank(req.getImei())) {
					builder.setImeiSha1(req.getImei());
				}
				if(StringUtils.isNotBlank(req.getImeiMd5())){
					builder.setImeiMd5(req.getImeiMd5());
				}
				if(StringUtils.isNotBlank(req.getUa())) {
					builder.setUa(req.getUa());
				}
				if(StringUtils.isNotBlank(req.getSdkVersion())){
					builder.setSdkVersion(req.getSdkVersion());
				}

				UserChannelS2S.SetChannelReq request = builder.build();

				byte[] data = BlinkUtils.invokeBlinkService(PropUtils.getSetUserChannelModelId(), set_channel_cmd_id,
						request.toByteArray());

				if (data != null) {
					UserChannelS2S.SetChannelRsp rsp = UserChannelS2S.SetChannelRsp.parseFrom(data);
					if (rsp.getRetCode() == RetCode.success.getCode()) {
						ownerChannel = rsp.getOwnerChannel();
					} else {
						logger.info("invoke blink service set user channel response code is "
								+ rsp.getRetCode());
					}
				} else {
					logger.info("invoke blink service set user channel response is null.");
				}
			}
		} catch (Exception e) {
			logger.error("", e);
		}
		return ownerChannel;
	}
}
