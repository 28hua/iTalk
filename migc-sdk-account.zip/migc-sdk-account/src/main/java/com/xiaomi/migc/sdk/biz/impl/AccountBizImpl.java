package com.xiaomi.migc.sdk.biz.impl;

import com.xiaomi.migc.sdk.biz.*;
import com.xiaomi.migc.sdk.common.RetCode;
import com.xiaomi.migc.sdk.exception.BizException;
import com.xiaomi.migc.sdk.model.AppAccountInfo;
import com.xiaomi.migc.sdk.model.OpenAccountInfo;
import com.xiaomi.migc.sdk.model.pb.FuidS2S;
import com.xiaomi.migc.sdk.model.vo.AccountVo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author mujiawang
 * @date 2018/12/28
 * @Version 1.0
 */
@Service
public class AccountBizImpl implements AccountBiz {

    @Autowired
    AppAccountInfoBiz appAccountInfoBiz;

    @Autowired
    OpenAccountInfoBiz openAccountInfoBiz;

    @Autowired
    FuidBiz fuidBiz;

    @Autowired
    CacheBiz cacheBiz;

    @Autowired
    EventDistributeBiz eventDistributeBiz;

    @Override
    public AccountVo getLastLoginAccount(long fuid, long devAppId, String imei) throws BizException {
        FuidS2S.AccountInfo fuidAccount = fuidBiz.getZhiboAccountInfoByUuid(fuid);
        if (fuidAccount == null) {
            throw new BizException(RetCode.reponseEmpty, "fuidAccountInfo get null");
        }
        long xiaomiId = 0L;
        if (fuidBiz.isXiaomiUser(fuidAccount)) {
            xiaomiId = Long.parseLong(fuidAccount.getOpenid());
        }
        long openId = 0L;
        boolean isFirst = false;
        String nickName = "";
        AccountVo vo = new AccountVo();
        if (StringUtils.isNotBlank(fuidAccount.getThirdNickname())) {
            nickName = fuidAccount.getThirdNickname();
        } else {
            FuidS2S.UserInfo fuidUserInfo = fuidBiz.getZhiboUserInfo(fuid);
            if (fuidUserInfo != null) {
                nickName = fuidUserInfo.getNickName();
            }
        }
        Long cacheOpenId = cacheBiz.getLastPlayedUid(fuid, devAppId);
        if (cacheOpenId != null && cacheOpenId.longValue() > 0L) {
            openId = cacheOpenId.longValue();
            vo.setOpenId(openId);
            vo.setFirst(isFirst);
            vo.setXiaomiId(xiaomiId);
            vo.setNickName(nickName);
            cacheBiz.setLastPlayedUid(fuid, devAppId, openId, imei);
            return vo;
        }
        if (xiaomiId > 0L) {
            AppAccountInfo appAccountInfo = appAccountInfoBiz.getLastPlayedAppAccount(xiaomiId, devAppId, fuid);
            openId = appAccountInfo.getAppAccountAlias();
            isFirst = appAccountInfo.isFirstLogin();
            if (isFirst) {
                eventDistributeBiz.oldToNewForApp(appAccountInfo, fuid, devAppId, null, false);
            }
        } else {
            OpenAccountInfo openAccountInfo = openAccountInfoBiz.getAccountInfo(fuid, devAppId);
            openId = openAccountInfo.getAppAccountId();
            isFirst = openAccountInfo.isFirstLogin();
            if (isFirst) {
                eventDistributeBiz.oldToNewForOpen(openAccountInfo, null, false);
            }
        }
        vo.setOpenId(openId);
        vo.setFirst(isFirst);
        vo.setXiaomiId(xiaomiId);
        vo.setNickName(nickName);
        cacheBiz.setLastPlayedUid(fuid, devAppId, openId, imei);
        return vo;
    }

    @Override
    public void saveLastPlayedAccount(long fuid, long devAppId, long openId) throws BizException {
        FuidS2S.AccountInfo fuidAccount = fuidBiz.getZhiboAccountInfoByUuid(fuid);
        if (fuidAccount == null) {
            return;
        }
        long xiaomiId = 0L;
        if (fuidBiz.isXiaomiUser(fuidAccount)) {
            xiaomiId = Long.parseLong(fuidAccount.getOpenid());
        }
        Date d = new Date();
        if (xiaomiId > 0L) {
            AppAccountInfo appAccountInfo = appAccountInfoBiz.getAppAccountInfoByAppAndAlias(openId, devAppId, xiaomiId);
            if (appAccountInfo != null) {
                appAccountInfo.setLastPlayedTime(d);
                appAccountInfo.setUpdateTime(d);
                cacheBiz.setLastPlayedUidForRecord(fuid, devAppId, openId);
                eventDistributeBiz.recordLastPlayedTime(fuid, xiaomiId, devAppId, openId);
                eventDistributeBiz.oldToNewForApp(appAccountInfo, fuid, devAppId, null, true);
            }
        } else {
            OpenAccountInfo openAccountInfo = openAccountInfoBiz.getByFuIdAndDevAppIdAndAppAccountId(openId, devAppId, fuid);
            if (openAccountInfo != null) {
                openAccountInfo.setLastPlayedTime(d);
                openAccountInfo.setUpdateTime(d);
                cacheBiz.setLastPlayedUidForRecord(fuid, devAppId, openId);
                eventDistributeBiz.recordLastPlayedTime(fuid, xiaomiId, devAppId, openId);
                eventDistributeBiz.oldToNewForOpen(openAccountInfo, null, true);
            }
        }
    }

    @Override
    public boolean verifyAccount(long openId, long fuid, long devAppId) throws BizException {
        return openAccountInfoBiz.verifyaccountinfo(openId, devAppId, fuid);
    }

    @Override
    public List<AccountVo> listAccounts(long fuid, long devAppId) throws BizException {
        FuidS2S.AccountInfo fuidAccount = fuidBiz.getZhiboAccountInfoByUuid(fuid);
        if (fuidAccount == null) {
            throw new BizException(RetCode.reponseEmpty, "fuidAccountInfo get null");
        }
        long xiaomiId = 0L;
        if (fuidBiz.isXiaomiUser(fuidAccount)) {
            xiaomiId = Long.parseLong(fuidAccount.getOpenid());
        }
        List<AccountVo> voList = new ArrayList<AccountVo>();
        if (xiaomiId > 0L) {
            List<AppAccountInfo> appAccountInfos = appAccountInfoBiz.findAppAccountInfosByXiaomiId(xiaomiId, devAppId);
            if (appAccountInfos == null || appAccountInfos.size() == 0) {
                throw new BizException(RetCode.reponseEmpty, "accounts is null");
            }
            for (AppAccountInfo info : appAccountInfos) {
                AccountVo vo = new AccountVo();
                vo.setOpenId(info.getAppAccountAlias());
                if (StringUtils.isNotBlank(info.getAppAccountName())) {
                    vo.setAccountName(info.getAppAccountName());
                }
                if (info.getLastPlayedTime() != null) {
                    vo.setLastPlayedTime(info.getLastPlayedTime().getTime());
                } else {
                    vo.setLastPlayedTime(info.getCreateTime() == null ? System.currentTimeMillis() : info.getCreateTime().getTime());
                }
                vo.setAccountType(info.getAccountType());
                voList.add(vo);
            }
        } else {
            throw new BizException(RetCode.reponseEmpty, "fuid is not xiaomiId");
        }
        return voList;
    }

    @Override
    public AccountVo getByThirdOpenId(String thirdOpenId, long devAppId, int thirdCode) throws BizException{
        long fuid = fuidBiz.getFuidByThirdOpenId(thirdOpenId, thirdCode);
        if (fuid == 0L) {
            throw new BizException(RetCode.getfuidByThirdOpenIdError);
        }
        OpenAccountInfo info = openAccountInfoBiz.getAccountInfo(fuid, devAppId);
        if (info.isFirstLogin()) {
            eventDistributeBiz.oldToNewForOpen(info, null, false);
        } else {
            eventDistributeBiz.oldToNewForOpen(info, null, true);
        }
        AccountVo vo = new AccountVo();
        vo.setOpenId(info.getAppAccountId());
        vo.setFuid(fuid);
        vo.setFirst(info.isFirstLogin());
        vo.setDevAppId(devAppId);
        return vo;
    }
}
