package com.xiaomi.migc.sdk.model;

/**
 * @author mujiawang
 * @date 2019/1/2
 * @Version 1.0
 */
public class GameIdMapping {

	private long masterExtId;
	private long masterDevAppId;
	private long slaveExtId;
	private long slaveDevAppId;
	public long getMasterExtId() {
		return masterExtId;
	}
	public void setMasterExtId(long masterExtId) {
		this.masterExtId = masterExtId;
	}
	public long getMasterDevAppId() {
		return masterDevAppId;
	}
	public void setMasterDevAppId(long masterDevAppId) {
		this.masterDevAppId = masterDevAppId;
	}
	public long getSlaveExtId() {
		return slaveExtId;
	}
	public void setSlaveExtId(long slaveExtId) {
		this.slaveExtId = slaveExtId;
	}
	public long getSlaveDevAppId() {
		return slaveDevAppId;
	}
	public void setSlaveDevAppId(long slaveDevAppId) {
		this.slaveDevAppId = slaveDevAppId;
	}

	/**
	 * 当前在用
	 */
	private long devAppId;

	public long getDevAppId() {
		return devAppId;
	}

	public void setDevAppId(long devAppId) {
		this.devAppId = devAppId;
	}
}
