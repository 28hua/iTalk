package com.xiaomi.migc.sdk.model;

import java.util.Date;

/**
 * 使用第三方账号登录游戏，生成的openId信息表
 * CREATE TABLE `open_account_info` (
   `id` bigint(20) NOT NULL,
   `fuid` bigint(20) DEFAULT NULL,
   `app_account_id` bigint(20) NOT NULL,
   `dev_app_id` bigint(20) DEFAULT NULL,
   `ext_id` bigint(20) DEFAULT NULL,
   `app_account_name` varchar(100) DEFAULT NULL,
   `account_type` int(1) NOT NULL,
   `account_status` int(11) DEFAULT NULL,
   `last_played_time` datetime DEFAULT NULL,
   `create_time` datetime DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `idx_fuid` (`fuid`),
   KEY `idx_dev_app_id` (`app_id`),
   KEY `idx_account_ct` (`create_time`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
 * @author jhw
 *
 */
public class OpenAccountInfo {

	private Long id;
	private Long fuid;
	private Long appAccountId;
	private Long extId;
	private Long devAppId;
	private String appAccountName;
	private int accountType;
	private int accountStatus;
	private Date createTime;
	private Date lastPlayedTime;
	private Date updateTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getFuid() {
		return fuid;
	}
	public void setFuid(Long fuid) {
		this.fuid = fuid;
	}
	public Long getExtId() {
		return extId;
	}
	public void setExtId(Long extId) {
		this.extId = extId;
	}
	public Long getDevAppId() {
		return devAppId;
	}
	public void setDevAppId(Long devAppId) {
		this.devAppId = devAppId;
	}
	public String getAppAccountName() {
		return appAccountName;
	}
	public void setAppAccountName(String appAccountName) {
		this.appAccountName = appAccountName;
	}
	public int getAccountType() {
		return accountType;
	}
	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}
	public int getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(int accountStatus) {
		this.accountStatus = accountStatus;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getLastPlayedTime() {
		return lastPlayedTime;
	}
	public void setLastPlayedTime(Date lastPlayedTime) {
		this.lastPlayedTime = lastPlayedTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Long getAppAccountId() {
		return appAccountId;
	}
	public void setAppAccountId(Long appAccountId) {
		this.appAccountId = appAccountId;
	}

	//for login event
	private boolean isFirstLogin;

	public boolean isFirstLogin() {
		return isFirstLogin;
	}

	public void setFirstLogin(boolean firstLogin) {
		isFirstLogin = firstLogin;
	}
}
