package com.xiaomi.migc.sdk.biz;

import com.xiaomi.migc.sdk.common.MasterAppIdUtils;
import com.xiaomi.migc.sdk.model.GameIdMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.migc.sdk.dao.AppExtDAO;
import com.xiaomi.migc.sdk.model.App;

@Service
public class AppBiz {

	private static final Logger logger = LoggerFactory.getLogger(AppBiz.class);

	@Autowired
	private AppExtDAO appExtDAO;

	@Autowired
    private CacheBiz cacheBiz;

    public long getAppMasterExtId(long devAppId) {
        long extId = cacheBiz.getExtIdByDevAppId(devAppId);
        if (extId == 0L) {
            GameIdMapping idMapping = MasterAppIdUtils.INSTANCE.getGameIdMapping(devAppId);
            if (idMapping != null) {
                extId = idMapping.getMasterExtId();
            }else {
                App app = appExtDAO.getAppExtInfoByDevAppId(devAppId);
                if (app != null) {
                    extId = app.getExtId();
                }
            }
            if (extId != 0L) {
                cacheBiz.setExtIdByDevAppId(devAppId, extId);
            }
        } else {
			logger.info("............. get extId from cache ..............");
		}

        return extId;
    }
}
