package com.xiaomi.migc.sdk.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xiaomi.migc.sdk.common.redis.RedisClient;

@Repository
public class OpenSessionCache {

	private static Logger logger = LoggerFactory.getLogger(OpenSessionCache.class);
	private static final int expire_time = 60 * 60 * 12;
	private static final String default_value = "1";
//	@Autowired
//	private RedisClusterClient redisClusterClient;
	@Autowired
	private RedisClient redisClient;
//	
	public void cacheOpenSession(long openId, long devAppId, String session) {
		String key = convertKey(openId,devAppId,session);
		
		logger.info("the open session cache key :" + key );
		redisClient.setex(key, expire_time, default_value);
	}

	public void cacheOpenSession(long openId, String session) {
		String key = convertKey(openId,session);
		redisClient.setex(key, expire_time, default_value);
	}

	public boolean isValidateSession(long openId, long devAppId, String session) {
		String key = convertKey(openId,devAppId,session);
		String value = redisClient.get(key);
		if(default_value.equals(value)) {
			return true;
		}
		return false;
	}

	public boolean isValidateSession(long openId, String session) {
		String key = convertKey(openId,session);
		String value = redisClient.get(key);
		if(default_value.equals(value)) {
			return true;
		}
		return false;
	}
	
	private String convertKey(long openId, long devAppId, String session) {
		StringBuilder sb = new StringBuilder();
		sb.append(session_prefix).append(openId).append(":")
		.append(devAppId).append(":").append(session);
		return sb.toString();
	}

	private String convertKey(long openId, String session) {
		StringBuilder sb = new StringBuilder();
		sb.append(session_prefix).append(openId).append(":")
				.append(":").append(session);
		return sb.toString();
	}

	private static final String session_prefix = "account:opensession:";
	
}
