package com.xiaomi.migc.sdk.model;

public class App {

	private Long extId;
    private String gameName;
    private String packageName;
    private String appKey;
    private int extStatus;
    private int status;
    private String allowXiaohao;
    private long devAppId;
    private String toolbarConfig;
    private String isDisplayToolbar;
    private String isControll;
    private int appType;
    private int loginAccountType;
    private String isDisplayLoginbar;
	public Long getExtId() {
		return extId;
	}
	public void setExtId(Long extId) {
		this.extId = extId;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public int getExtStatus() {
		return extStatus;
	}
	public void setExtStatus(int extStatus) {
		this.extStatus = extStatus;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getAllowXiaohao() {
		return allowXiaohao;
	}
	public void setAllowXiaohao(String allowXiaohao) {
		this.allowXiaohao = allowXiaohao;
	}
	public long getDevAppId() {
		return devAppId;
	}
	public void setDevAppId(long devAppId) {
		this.devAppId = devAppId;
	}
	public String getToolbarConfig() {
		return toolbarConfig;
	}
	public void setToolbarConfig(String toolbarConfig) {
		this.toolbarConfig = toolbarConfig;
	}
	public String getIsDisplayToolbar() {
		return isDisplayToolbar;
	}
	public void setIsDisplayToolbar(String isDisplayToolbar) {
		this.isDisplayToolbar = isDisplayToolbar;
	}
	public String getIsControll() {
		return isControll;
	}
	public void setIsControll(String isControll) {
		this.isControll = isControll;
	}
	public int getAppType() {
		return appType;
	}
	public void setAppType(int appType) {
		this.appType = appType;
	}
	public int getLoginAccountType() {
		return loginAccountType;
	}
	public void setLoginAccountType(int loginAccountType) {
		this.loginAccountType = loginAccountType;
	}
	public String getIsDisplayLoginbar() {
		return isDisplayLoginbar;
	}
	public void setIsDisplayLoginbar(String isDisplayLoginbar) {
		this.isDisplayLoginbar = isDisplayLoginbar;
	}
}
