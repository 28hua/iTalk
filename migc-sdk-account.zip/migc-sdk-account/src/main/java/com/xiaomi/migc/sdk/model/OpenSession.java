package com.xiaomi.migc.sdk.model;

public class OpenSession {

	private Long openId;
	private Long devAppId;
	private String session;
	private Long createTime;
	private Long expireTime;
	public Long getOpenId() {
		return openId;
	}
	public void setOpenId(Long openId) {
		this.openId = openId;
	}
	public Long getDevAppId() {
		return devAppId;
	}
	public void setDevAppId(Long devAppId) {
		this.devAppId = devAppId;
	}
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public Long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}
	public Long getExpireTime() {
		return expireTime;
	}
	public void setExpireTime(Long expireTime) {
		this.expireTime = expireTime;
	}
}
