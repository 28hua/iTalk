package com.xiaomi.migc.sdk.model.vo;

import com.xiaomi.migc.sdk.common.Constants;

/**
 * @author mujiawang
 * @date 2018/12/28
 * @Version 1.0
 */
public class AccountVo {

    private long openId;

    private long devAppId;

    private long fuid;

    private String accountName = Constants.DEFAULT_ACCOUNT_NAME;

    private long lastPlayedTime;

    private long xiaomiId;

    private int accountType;

    private String nickName = "";

    private boolean isFirst = false;

    public long getOpenId() {
        return openId;
    }

    public void setOpenId(long openId) {
        this.openId = openId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public long getLastPlayedTime() {
        return lastPlayedTime;
    }

    public void setLastPlayedTime(long lastPlayedTime) {
        this.lastPlayedTime = lastPlayedTime;
    }

    public boolean isFirst() {
        return isFirst;
    }

    public void setFirst(boolean first) {
        isFirst = first;
    }

    public long getXiaomiId() {
        return xiaomiId;
    }

    public void setXiaomiId(long xiaomiId) {
        this.xiaomiId = xiaomiId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    public long getDevAppId() {
        return devAppId;
    }

    public void setDevAppId(long devAppId) {
        this.devAppId = devAppId;
    }

    public long getFuid() {
        return fuid;
    }

    public void setFuid(long fuid) {
        this.fuid = fuid;
    }
}
