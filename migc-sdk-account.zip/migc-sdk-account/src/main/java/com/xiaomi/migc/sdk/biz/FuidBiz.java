package com.xiaomi.migc.sdk.biz;

import com.google.protobuf.InvalidProtocolBufferException;
import com.xiaomi.huyu.blink.client.BlinkClient;
import com.xiaomi.huyu.blink.client.ClientFactory;
import com.xiaomi.huyu.blink.client.Command;
import com.xiaomi.huyu.blink.client.Config;
import com.xiaomi.huyu.blink.client.model.BlinkResponse;
import com.xiaomi.migc.sdk.common.PropUtils;
import com.xiaomi.migc.sdk.model.pb.FuidS2S;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class FuidBiz {

    private Logger logger = LoggerFactory.getLogger(FuidBiz.class);

    private static final int appid = 20002;
    private static final int USER_PROFILE_L5_CMD_ID = 1002;
    private static final int USER_PROFILE_HEARDER_ID = 1002;
    private static final int timeout = 3000;

    private static final int EXPIRETIMESEC = 2592000; // 单位秒, 30天

    public FuidS2S.UserInfo getZhiboUserInfo(long uuid) {
        Config config = new Config(PropUtils.getUserProfileModelId());
        config.setEnableL5RoutingPolicy(true);
        config.setConnectionPoolSize(30);
        BlinkClient blinkClient = ClientFactory.getInstance(config);
        Command command = new Command(USER_PROFILE_HEARDER_ID, USER_PROFILE_L5_CMD_ID);
        FuidS2S.GetUserInfoReq request = FuidS2S.GetUserInfoReq.newBuilder().setAppid(appid).setUuid(uuid).build();

        BlinkResponse response = blinkClient.invoke(command, request.toByteArray(), timeout);
        if (response.isSuccess()) {

            try {
                FuidS2S.GetUserInfoRsp getUserInfoRsp = FuidS2S.GetUserInfoRsp.parseFrom(response.getBody());

                if (getUserInfoRsp != null) {
                    if (isSuccess(getUserInfoRsp.getRet())) {
                        return getUserInfoRsp.getUserinfo();
                    } else {
                        logger.info("The GetUserInfo response is error! " + getUserInfoRsp.getRet());
                    }

                }
            } catch (InvalidProtocolBufferException e) {

                logger.info("The GetUserInfo response is error! ", e);
            }

        } else {
            logger.info("The GetUserInfo response is error! ");
        }

        return null;
    }

    public FuidS2S.AccountInfo getZhiboAccountInfoByUuid(long uuid) {
        Config config = new Config(PropUtils.getZhiboAccountModelId()); // 50024
                                                                              // 10028
        config.setConnectionPoolSize(30);
        config.setEnableL5RoutingPolicy(true);
        BlinkClient blinkClient = ClientFactory.getInstance(config);
        Command command = new Command(1005, 1005);

        FuidS2S.GetAccountInfoReq request = FuidS2S.GetAccountInfoReq.newBuilder().setUuid(uuid).build();

        BlinkResponse response = blinkClient.invoke(command, request.toByteArray(), timeout);
        if (response.isSuccess()) {

            try {
                FuidS2S.GetAccountInfoRsp getAccountInfoRsp = FuidS2S.GetAccountInfoRsp.parseFrom(response.getBody());

                logger.info("The zhibo accountinfo is retCode : " + getAccountInfoRsp.getRetCode());
                if (getAccountInfoRsp != null && isSuccess(getAccountInfoRsp.getRetCode())) {
                    return getAccountInfoRsp.getAccountInfo();
                }
            } catch (InvalidProtocolBufferException e) {

                logger.info("The GetUserInfo response is error! ", e);
            }

        } else {
            logger.info("The GetUserInfo response is error! ");
        }

        return null;
    }

    public boolean isValidateToken(String token, long fuid) {

        Config config = new Config(PropUtils.getZhiboAccountModelId()); // 50024
                                                                              // 10028
        config.setConnectionPoolSize(30);
        config.setEnableL5RoutingPolicy(true);
        BlinkClient blinkClient = ClientFactory.getInstance(config);
        Command command = new Command(1002, 1002);

        FuidS2S.VerifyServiceTokenReq request = FuidS2S.VerifyServiceTokenReq.newBuilder().setServicetoken(token)
                .setExpireTimeSec(EXPIRETIMESEC).setIsSingleSignon(true).build();

        BlinkResponse response = blinkClient.invoke(command, request.toByteArray(), timeout);
        if (response.isSuccess()) {

            try {
                FuidS2S.VerifyServiceTokenRsp rsp = FuidS2S.VerifyServiceTokenRsp.parseFrom(response.getBody());
                logger.info("The isValidateToken response is {}, ", rsp.toString());
                if (rsp != null && isSuccess(rsp.getRetCode())) {
                    if (rsp.getUuid() == fuid) {
                        return true;
                    }
                }
            } catch (InvalidProtocolBufferException e) {

                logger.info("The isValidateToken response is error! ", e);
            }

        } else {
            logger.info("The isValidateToken response is error! "+ response.getClientErrorCode());  
            logger.info("The isValidateToken response is error! "+ response.getEndpoint().getHostName() + ":" + response.getEndpoint().getPort());
        }

        return false;
    }

    public long getFuidByThirdOpenId(String thirdOpenId, int thirdCode) {
        Config config = new Config(PropUtils.getZhiboAccountModelId()); // 50024// 10028
        config.setConnectionPoolSize(30);
        config.setEnableL5RoutingPolicy(true);
        BlinkClient blinkClient = ClientFactory.getInstance(config);
        Command command = new Command(1018, 1006);

        FuidS2S.GetGamecenidByOpenidReq req = FuidS2S.GetGamecenidByOpenidReq.newBuilder()
                .setOpenId(thirdOpenId).setAccountType(thirdCode).setAppid(20002).build();

        try {
            BlinkResponse response = blinkClient.invoke(command, req.toByteArray(), timeout);
            if (response.isSuccess()) {
                FuidS2S.GetGamecenidByOpenidRsp rsp = FuidS2S.GetGamecenidByOpenidRsp.parseFrom(response.getBody());
                logger.info("GetGamecenidByOpenidRsp {}", rsp.toString());
                if (rsp.getRetCode() == 0) {
                    return rsp.getZuid();
                }
            }
        } catch (Exception e) {
            logger.error("", e);
        }

        return 0L;
    }

    public boolean isXiaomiUser(FuidS2S.AccountInfo user) {
        if (user.getAccountType() == 4) {
            return true;
        }
        return false;
    }

    private boolean isSuccess(int retCode) {
        if (retCode == 0) {
            return true;
        }
        return false;
    }
}
