package com.xiaomi.migc.sdk.biz;

import com.xiaomi.migc.sdk.common.Constants;
import com.xiaomi.migc.sdk.common.MasterAppIdUtils;
import com.xiaomi.migc.sdk.model.AppAccountInfo;
import com.xiaomi.migc.sdk.model.OpenAccountInfo;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;
import com.xiaomi.migc.thrift.event.distribute.models.GameAccountInfo;
import com.xiaomi.migc.thrift.event.distribute.models.LoginEventReq;
import com.xiaomi.migc.thrift.event.distribute.models.RecordLastPlayedTimeReq;
import com.xiaomi.migc.thrift.event.distribute.service.DistributeService;
import com.xiaomi.miliao.thrift.ClientFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author mujiawang
 * @date 2018/12/27
 * @Version 1.0
 */
@Service
public class EventDistributeBiz {

    @Autowired
    AppBiz appBiz;

    protected static DistributeService.Iface client;

    private static final Logger logger = LoggerFactory.getLogger(EventDistributeBiz.class);

    static {
        client = ClientFactory.getClient(DistributeService.Iface.class);
    }

    public void loginEvent(AccountS2C.GetLoginAppAccountReq accountReq,
                           int retCode, long xiaomiId, boolean isFirst, long openId, String openSession) {
        try {
            long devAppId = Long.parseLong(accountReq.getDevAppId());
            LoginEventReq req = new LoginEventReq();
            req.setFuid(accountReq.getFuid());
            req.setDevAppId(devAppId);
            req.setMiId(xiaomiId);
            req.setExtId(appBiz.getAppMasterExtId(devAppId));
            req.setOpenId(openId);
            req.setIsFirst(isFirst);
            req.setLoginTime(System.currentTimeMillis());
            req.setOpenSession(openSession);
            req.setToken(accountReq.getToke());
            req.setRetCode(retCode);
            if (StringUtils.isNotBlank(accountReq.getImei())) {
                req.setImei(accountReq.getImei());
            }
            if (StringUtils.isNotBlank(accountReq.getImeiMd5())) {
                req.setImeiMd5(accountReq.getImeiMd5());
            }
            if (StringUtils.isNotBlank(accountReq.getImsi())) {
                req.setImsi(accountReq.getImsi());
            }
            if (StringUtils.isNotBlank(accountReq.getSdkVersion())) {
                req.setSdkVersion(accountReq.getSdkVersion());
            }
            if (StringUtils.isNotBlank(accountReq.getUa())) {
                req.setUa(accountReq.getUa());
            }
            if (StringUtils.isNotBlank(accountReq.getChannel())) {
                req.setChannel(accountReq.getChannel());
            }
            if (StringUtils.isNotBlank(accountReq.getFirstChannel())) {
                req.setFirstChannel(accountReq.getFirstChannel());
            }
            if (StringUtils.isNotBlank(accountReq.getCurrentChannel())) {
                req.setCurrentChannel(accountReq.getCurrentChannel());
            }
            client.loginEvent(req);
        } catch (Exception e) {
            logger.error("loginEventError#", e);
        }

    }

    public void recordLastPlayedTime(long fuid, long xiaomiId, long devAppId, long openId) {
        try {
            RecordLastPlayedTimeReq req = new RecordLastPlayedTimeReq();
            req.setFuid(fuid);
            req.setMiId(xiaomiId);
            req.setDevAppId(devAppId);
            req.setExtId(appBiz.getAppMasterExtId(devAppId));
            req.setOpenId(openId);
            req.setLastPlayedLoginTime(System.currentTimeMillis());
            req.setIsNewDB(false);
            client.recordLastPlayedTime(req);
        } catch (Exception e) {
            logger.error("recordLastPlayedTimeError#", e);
        }
    }

    public void oldToNewForApp(AppAccountInfo info, long fuid, long devAppId, String channel, boolean update) {

        try {
            GameAccountInfo gameAccountInfo = new GameAccountInfo();
            gameAccountInfo.setOpenId(info.getAppAccountAlias());
            gameAccountInfo.setFuid(fuid);
            gameAccountInfo.setDevAppId(MasterAppIdUtils.INSTANCE.getDevAppId(devAppId));
            gameAccountInfo.setAccountType(info.getAccountType());
            gameAccountInfo.setStatus(info.getAccountStatus());
            if (StringUtils.isNotBlank(info.getAppAccountName())) {
                gameAccountInfo.setAccountName(info.getAppAccountName());
            } else {
                gameAccountInfo.setAccountName(Constants.DEFAULT_ACCOUNT_NAME);
            }
            gameAccountInfo.setLastLoginTime(info.getLastPlayedTime().getTime());
            gameAccountInfo.setCreateTime(info.getCreateTime().getTime());
            gameAccountInfo.setUpdateTime(info.getUpdateTime().getTime());
            if (StringUtils.isNotBlank(channel)) {
                gameAccountInfo.setChannel(channel);
            }
            gameAccountInfo.setIsXiaoMi(true);
            gameAccountInfo.setMiId(info.getXiaomiId());
            gameAccountInfo.setExtId(info.getAppId());
            gameAccountInfo.setUpdate(update);

            client.saveAccount(gameAccountInfo);
        } catch (Exception e) {
            logger.error("old2newForApp#", e);
        }

    }

    public void oldToNewForOpen(OpenAccountInfo info, String channel, boolean update) {
        try {
            GameAccountInfo gameAccountInfo = new GameAccountInfo();
            gameAccountInfo.setOpenId(info.getAppAccountId());
            gameAccountInfo.setFuid(info.getFuid());
            gameAccountInfo.setDevAppId(info.getDevAppId());
            gameAccountInfo.setAccountType(info.getAccountType());
            gameAccountInfo.setStatus(info.getAccountStatus());
            if (StringUtils.isNotBlank(info.getAppAccountName())) {
                gameAccountInfo.setAccountName(info.getAppAccountName());
            } else {
                gameAccountInfo.setAccountName(Constants.DEFAULT_ACCOUNT_NAME);
            }
            gameAccountInfo.setLastLoginTime(info.getLastPlayedTime().getTime());
            gameAccountInfo.setCreateTime(info.getCreateTime().getTime());
            gameAccountInfo.setUpdateTime(info.getUpdateTime().getTime());
            if (StringUtils.isNotBlank(channel)) {
                gameAccountInfo.setChannel(channel);
            }
            gameAccountInfo.setIsXiaoMi(false);
            gameAccountInfo.setUpdate(update);

            client.saveAccount(gameAccountInfo);
        } catch (Exception e) {
            logger.error("old2newForOpen#", e);
        }
    }
}
