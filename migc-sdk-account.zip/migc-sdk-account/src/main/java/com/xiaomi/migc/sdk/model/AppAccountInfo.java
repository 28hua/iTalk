package com.xiaomi.migc.sdk.model;

import java.util.Date;

import com.xiaomi.migc.sdk.common.Constants;

/**
 * @author jhw
 *
 */
public class AppAccountInfo {

	private long appAccountId;
	private long xiaomiId;
	private long appId;
	private String appAccountName;
	private int accountStatus = Constants.ACCOUNT_STATUS_ON;
	private Date lastPlayedTime;
	private Date createTime;
	private Date updateTime;
	
	private long appAccountAlias;
	private int accountType;
	
	public long getAppAccountId() {
		return appAccountId;
	}
	public void setAppAccountId(long appAccountId) {
		this.appAccountId = appAccountId;
	}
	public long getXiaomiId() {
		return xiaomiId;
	}
	public void setXiaomiId(long xiaomiId) {
		this.xiaomiId = xiaomiId;
	}
	public long getAppId() {
		return appId;
	}
	public void setAppId(long appId) {
		this.appId = appId;
	}
	public String getAppAccountName() {
		return appAccountName;
	}
	public void setAppAccountName(String appAccountName) {
		this.appAccountName = appAccountName;
	}
	public int getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(int accountStatus) {
		this.accountStatus = accountStatus;
	}
	public Date getLastPlayedTime() {
		return lastPlayedTime;
	}
	public void setLastPlayedTime(Date lastPlayedTime) {
		this.lastPlayedTime = lastPlayedTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public long getAppAccountAlias() {
		return appAccountAlias;
	}
	public void setAppAccountAlias(long appAccountAlias) {
		this.appAccountAlias = appAccountAlias;
	}
	public int getAccountType() {
		return accountType;
	}
	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}

	//for login event
	private boolean isFirstLogin;


	public boolean isFirstLogin() {
		return isFirstLogin;
	}

	public void setFirstLogin(boolean firstLogin) {
		isFirstLogin = firstLogin;
	}

}
