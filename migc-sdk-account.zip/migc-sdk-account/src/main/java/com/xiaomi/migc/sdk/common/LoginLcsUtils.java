package com.xiaomi.migc.sdk.common;

import com.xiaomi.huyu.blink.BlinkConstants;
import com.xiaomi.huyu.blink.utils.ConfigUtils;
import com.xiaomi.infra.galaxy.lcs.common.module.TopicAndTeam;
import com.xiaomi.infra.galaxy.lcs.log.log4j.LCSLogger;
import com.xiaomi.migc.sdk.model.pb.AccountS2C;
import com.xiaomi.miliao.utils.Base64Coder;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author mujiawang
 * @date 2018/8/2
 * @Version 1.0
 */
public class LoginLcsUtils {

    public static String D_PROC_TAG = "";

    public static AtomicLong dIndex = new AtomicLong(0L);

    private static LCSLogger talosLogger = new LCSLogger();

    private static final Logger lcsLoginLogger = LoggerFactory.getLogger("lcsLoginLogger");

    private static TopicAndTeam topicAndTeam;

    private static Properties properties = ConfigUtils.loadProperties(BlinkConstants.Properties.DEFAULT_APPLICATION_PROPERTIES);

    static {
        try {
            String serverIp = InetAddress.getLocalHost().getHostAddress();
            String name = ManagementFactory.getRuntimeMXBean().getName();
            String pid = name.split("@")[0];
            D_PROC_TAG = serverIp + "_" + pid;
            topicAndTeam = new TopicAndTeam(properties.getProperty("login.lcslogger.clustername"),
                    properties.getProperty("login.lcslogger.orgid"),
                    properties.getProperty("login.lcslogger.topicname"),
                    properties.getProperty("login.lcslogger.teamid"));

        } catch (Exception e) {
            lcsLoginLogger.error("", e);
        }
    }


    public static void log(AccountS2C.GetLoginAppAccountReq req, int retCode, long openId) {
        try {
            if (req != null) {
                JSONObject dataJson = new JSONObject();
                dataJson.put("fuid", req.getFuid());
                dataJson.put("devAppId", req.getDevAppId());
                dataJson.put("token", req.getToke());
                dataJson.put("imei", req.getImei());
                dataJson.put("imsi", req.getImsi());
                dataJson.put("sdkVersion", req.getSdkVersion());
                dataJson.put("channel", req.getChannel());
                dataJson.put("ua", req.getUa());
                dataJson.put("currentChannel", req.getCurrentChannel());
                dataJson.put("imeiMd5", req.getImeiMd5());
                dataJson.put("firstChannel", req.getFirstChannel());
                dataJson.put("retCode", retCode);
                dataJson.put("openId", openId);

                String data = URLEncoder.encode(Base64Coder.encodeString(dataJson.toString()), "UTF-8");
                String ts = String.valueOf(System.currentTimeMillis());

                StringBuilder sb = new StringBuilder();
                sb.append("ac=sdk_s_login&data=").append(data).append("&dIndex=").append(dIndex.incrementAndGet())
                        .append("&dProcTag=").append(D_PROC_TAG).append("&fromApp=migc-sdk-account&ts=").append(ts)
                        .append("&sign=");

                lcsLoginLogger.info(dataJson.toString());
                talosLogger.write(topicAndTeam, sb.toString());
            }
        } catch (Exception e) {
            lcsLoginLogger.error("", e);
        }

    }

}
