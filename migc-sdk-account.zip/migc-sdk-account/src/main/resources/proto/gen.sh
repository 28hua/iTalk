#!/bin/bash
protoc --java_out=../../java/ account_s2c.proto
protoc --java_out=../../java/ fuid_s2s.proto