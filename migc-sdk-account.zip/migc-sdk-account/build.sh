#!/bin/bash

# 部署系统会将项目在部署系统中的名字作为第一个参数传递给 build.sh
# 因为 httpprocess 所在的 git 源中包含多个模块,
# 所以我们需要通过这个参数区分不同模块的编译动作
job=$1
cluster=$(echo $job |sed -n 's/.*_cluster\.\([^._]*\)_.*/\1/p')

# cluster 的值可能是staging，production-[sd|lg|hh], onebox,具体值在部署时会传过来
mvn -U clean package -D$cluster=true && \
mkdir release && \
cp -r deploy scripts target/*.war release/ && \
cd release && jar -xvf *.war && /bin/rm *.war
