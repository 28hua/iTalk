insert into open_account_info(fuid,app_account_id,dev_app_id,account_type,account_status,create_time,last_played_time,update_time) values(69424860,2017042805473370,2882303761517442428,1,1,current_timestamp(),current_timestamp(),current_timestamp());
insert into open_account_info(fuid,app_account_id,dev_app_id,account_type,account_status,create_time,last_played_time,update_time) values(1102311496,2017081101491348,2882303761517442428,1,1,current_timestamp(),current_timestamp(),current_timestamp());

insert into sdk_global_settings(item_key,item_value,create_time,update_time) values ('is_rebate','false',current_timestamp(),current_timestamp());
insert into sdk_global_settings(item_key,item_value,create_time,update_time) values ('rebate_toast','米币礼券抵扣金额不参与返利活动',current_timestamp(),current_timestamp());
insert into sdk_global_settings(item_key,item_value,create_time,update_time) values ('announcement','避免过度游戏损害身心健康。请合理安排游戏时间。\n未成年人游戏充值，请在监护人陪同下完成。',current_timestamp(),current_timestamp());