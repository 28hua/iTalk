#!/bin/env python
#
# Push monit data to falcon(monitor system)
#
# Useage : $0 <http-port> <tag-string>
# Example: $0 8081 cop.xiaomi_owt.game_pdl.bill_cluster.production-hh_service.order_job.bizapi_status.service_loc.bj_idc.hh
#
# Note: the http://localhost:<http-port>/api/status output format should like this:
#{
#    "data": [
#        {
#            "CounterType": "COUNTER",
#            "Metric": "java.callback.cp.times",
#            "Comment": "Callback cp server order times.",
#            "value": 23916
#        }
#    ]
#}
#
# Auther: chengshengbo@xiaomi.com
#

import sys, urllib2, base64, json, time,socket


step = 60
ip = socket.gethostname()
ts = int(time.time())
port = sys.argv[1]
tag  = sys.argv[2].replace('_',',').replace('.','=')

request = urllib2.Request("http://%s:%s/api/status" %(ip,port))
result = urllib2.urlopen(request)
data = json.loads(result.read())['data']

p = []
for item in data:
	i = {}
	i["endpoint"] = ip
	i['timestamp'] = ts
	i['step'] = step
	i['counterType'] = item['CounterType']
	i['metric'] = item['Metric']
	i['tags'] = tag
	i['value'] = item['value']
	p.append(i)

print json.dumps(p, indent=4)


method = "POST"
handler = urllib2.HTTPHandler()
opener = urllib2.build_opener(handler)
url = 'http://127.0.0.1:1988/v1/push'
request = urllib2.Request(url, data=json.dumps(p) )
request.add_header("Content-Type",'application/json')
request.get_method = lambda: method
try:
    connection = opener.open(request)
except urllib2.HTTPError,e:
    connection = e

# check. Substitute with appropriate HTTP code.
if connection.code == 200:
    print connection.read()
else:
    print '{"err":1,"msg":"%s"}' % connection
